# 🚀 Configuración Rápida de Correo Electrónico

## ✅ Estado Actual

El sistema de correo está **instalado y listo**, pero necesita credenciales de Gmail para funcionar.

## 📝 Pasos para Activar el Envío de Correos

### Paso 1: Crear archivo `.env`

Crea un archivo llamado `.env` en la carpeta `api/Api/` con este contenido:

```env
EMAIL_USER=tu_email@gmail.com
EMAIL_PASSWORD=tu_contraseña_de_aplicacion
```

### Paso 2: Obtener Contraseña de Aplicación de Gmail

1. **Ve a:** https://myaccount.google.com/apppasswords
   - Si no ves esta opción, primero activa "Verificación en 2 pasos" en: https://myaccount.google.com/security

2. **Selecciona:**
   - **Aplicación:** Correo
   - **Dispositivo:** Otro (nombre personalizado)
   - **Nombre:** `Inspira Salud API`

3. **Copia la contraseña de 16 caracteres** que aparece (ejemplo: `abcd efgh ijkl mnop`)

4. **Pégala en el archivo `.env`** (sin espacios o con espacios, ambos funcionan)

### Paso 3: Ejemplo de `.env` Completo

```env
EMAIL_USER=inspirasalud.app@gmail.com
EMAIL_PASSWORD=abcd efgh ijkl mnop
```

### Paso 4: Reiniciar el Servidor

El servidor se reiniciará automáticamente con `nodemon`. Si no, ejecuta:

```bash
npm run dev
```

Deberías ver:
```
✅ Servicio de correo configurado correctamente.
```

## 🧪 Verificar que Funciona

1. **Prueba el endpoint desde la app:**
   - Ve a "Recuperar Contraseña"
   - Ingresa un correo registrado
   - Revisa la bandeja de entrada del correo

2. **O prueba con el script:**
   ```bash
   node test-email.js
   ```

## ⚠️ Notas Importantes

- **Gmail:** Permite ~500 correos/día en cuentas personales
- **Seguridad:** El archivo `.env` NO se sube al repositorio (está en .gitignore)
- **Producción:** Para producción, considera usar SendGrid o Mailgun

## 🐛 Solución de Problemas

### Error: "Invalid login"
- Verifica que la contraseña de aplicación sea correcta
- Asegúrate de haber copiado todos los 16 caracteres
- Verifica que la verificación en 2 pasos esté activada

### Los correos no llegan
- Revisa la carpeta de spam
- Verifica que el correo esté bien escrito
- Revisa los logs del servidor para ver errores

### "Servicio de correo no configurado"
- Verifica que el archivo `.env` existe en `api/Api/`
- Verifica que las variables `EMAIL_USER` y `EMAIL_PASSWORD` estén correctas
- Reinicia el servidor después de crear/modificar `.env`

## ✅ Una vez Configurado

Cada vez que un usuario solicite recuperación de contraseña:
1. Se generará un código de 6 dígitos
2. Se guardará en la base de datos
3. **Se enviará automáticamente por correo** al usuario
4. El código expira en 15 minutos

