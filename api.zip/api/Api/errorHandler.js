// =====================================================
// Manejador Centralizado de Errores
// =====================================================

/**
 * Clase personalizada para errores de la API
 */
class ApiError extends Error {
  constructor(message, statusCode = 500, code = "UNKNOWN_ERROR") {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.isOperational = true;
    Error.captureStackTrace(this, this.constructor);
  }
}

/**
 * Manejo centralizado de errores con mensajes claros
 */
function handleError(error, req, res, next) {
  // Si el error ya tiene un formato de respuesta, usarlo
  if (error.statusCode && error.code) {
    return res.status(error.statusCode).json({
      success: false,
      error: error.message,
      code: error.code,
      ...(process.env.NODE_ENV === "development" && { stack: error.stack })
    });
  }
  
  // Errores de MySQL
  if (error.code === "ER_DUP_ENTRY") {
    return res.status(409).json({
      success: false,
      error: "El registro ya existe en la base de datos",
      code: "DUPLICATE_ENTRY"
    });
  }
  
  if (error.code === "ER_NO_SUCH_TABLE") {
    return res.status(500).json({
      success: false,
      error: "Error en la base de datos. Contacte al administrador",
      code: "DATABASE_ERROR"
    });
  }
  
  if (error.code === "ECONNREFUSED") {
    return res.status(503).json({
      success: false,
      error: "No se pudo conectar a la base de datos",
      code: "DATABASE_CONNECTION_ERROR"
    });
  }
  
  // Errores de validación
  if (error.name === "ValidationError") {
    return res.status(400).json({
      success: false,
      error: error.message || "Error de validación",
      code: "VALIDATION_ERROR",
      details: error.details
    });
  }
  
  // Error por defecto
  console.error("❌ Error no manejado:", error);
  res.status(error.statusCode || 500).json({
    success: false,
    error: process.env.NODE_ENV === "production" 
      ? "Ha ocurrido un error en el servidor" 
      : error.message,
    code: error.code || "INTERNAL_SERVER_ERROR",
    ...(process.env.NODE_ENV === "development" && { 
      stack: error.stack,
      details: error 
    })
  });
}

/**
 * Wrapper para manejar errores en funciones async
 */
function asyncHandler(fn) {
  return (req, res, next) => {
    Promise.resolve(fn(req, res, next)).catch(next);
  };
}

/**
 * Mensajes de error amigables
 */
const ErrorMessages = {
  // Autenticación
  INVALID_CREDENTIALS: "Correo o contraseña incorrectos",
  USER_NOT_FOUND: "Usuario no encontrado",
  USER_INACTIVE: "Su cuenta está desactivada. Contacte al administrador",
  
  // Validación
  MISSING_FIELDS: "Faltan campos requeridos",
  INVALID_EMAIL: "El correo electrónico no es válido",
  INVALID_PASSWORD: "La contraseña debe tener al menos 8 caracteres",
  
  // Base de datos
  DATABASE_ERROR: "Error al procesar la solicitud. Intente más tarde",
  CONNECTION_ERROR: "No se pudo conectar al servidor",
  
  // Recursos
  NOT_FOUND: "El recurso solicitado no fue encontrado",
  UNAUTHORIZED: "No está autorizado para realizar esta acción",
  FORBIDDEN: "Acceso prohibido",
  
  // General
  INTERNAL_ERROR: "Ha ocurrido un error interno. Intente más tarde",
  TIMEOUT: "La solicitud tardó demasiado tiempo. Intente nuevamente"
};

/**
 * Crea un error con mensaje amigable
 */
function createError(message, statusCode = 500, code = "UNKNOWN_ERROR") {
  return new ApiError(message, statusCode, code);
}

module.exports = {
  ApiError,
  handleError,
  asyncHandler,
  ErrorMessages,
  createError
};

