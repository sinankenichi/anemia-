# 📧 Configuración de Envío de Correos - Guía Paso a Paso

## 🎯 Solución Implementada: Gmail SMTP (100% Gratis)

He implementado un sistema de envío de correos usando **Nodemailer con Gmail SMTP**, que es completamente gratuito y funciona con cualquier cuenta de Gmail.

---

## 📋 Pasos para Configurar

### Paso 1: Instalar Dependencias

Abre una terminal en la carpeta `api/Api` y ejecuta:

```bash
npm install nodemailer dotenv
```

### Paso 2: Activar Verificación en 2 Pasos en Gmail

1. Ve a tu cuenta de Google: https://myaccount.google.com/
2. Ve a **Seguridad** (Security)
3. Busca **Verificación en 2 pasos** (2-Step Verification)
4. Actívala si no está activada (necesario para generar contraseñas de aplicación)

### Paso 3: Generar Contraseña de Aplicación

1. Ve a: https://myaccount.google.com/apppasswords
   - O busca "Contraseñas de aplicaciones" en tu cuenta de Google
2. Selecciona:
   - **Aplicación:** Correo
   - **Dispositivo:** Otro (nombre personalizado)
   - Escribe: **"Inspira Salud API"**
3. Haz clic en **Generar**
4. **Copia la contraseña de 16 caracteres** que aparece (ejemplo: `abcd efgh ijkl mnop`)

⚠️ **IMPORTANTE:** Esta contraseña es diferente a tu contraseña normal de Gmail. Úsala solo para la aplicación.

### Paso 4: Crear Archivo de Configuración

Crea un archivo llamado `.env` en la carpeta `api/Api/` con el siguiente contenido:

```env
EMAIL_USER=tu_email@gmail.com
EMAIL_PASSWORD=abcd efgh ijkl mnop
```

**Ejemplo real:**
```env
EMAIL_USER=inspirasalud.app@gmail.com
EMAIL_PASSWORD=abcd efgh ijkl mnop
```

⚠️ **NO subas el archivo `.env` al repositorio** (ya está en .gitignore)

### Paso 5: Reiniciar el Servidor

Reinicia tu servidor Node.js:

```bash
npm run dev
```

Deberías ver en la consola:
```
✅ Servicio de correo configurado correctamente.
```

---

## ✅ Verificar que Funciona

1. Solicita recuperación de contraseña desde la app
2. Revisa la bandeja de entrada del correo registrado
3. Deberías recibir un correo con el código de 6 dígitos

---

## 🔄 Alternativas Gratuitas (Si Gmail no funciona)

### Opción 1: SendGrid (Recomendado para producción)
- **Gratis:** 100 emails/día
- **Registro:** https://sendgrid.com/
- **Ventaja:** Más confiable, mejor para producción

**Configuración:**
1. Regístrate en SendGrid
2. Crea una API Key
3. Modifica `emailService.js` para usar SendGrid en lugar de Gmail

### Opción 2: Mailgun
- **Gratis:** 5,000 emails/mes
- **Registro:** https://www.mailgun.com/
- **Ventaja:** Gran cantidad de emails gratis

### Opción 3: Brevo (Sendinblue)
- **Gratis:** 300 emails/día
- **Registro:** https://www.brevo.com/
- **Ventaja:** Interfaz fácil, buen soporte

---

## 🐛 Solución de Problemas

### Error: "Invalid login"
- Verifica que la contraseña de aplicación sea correcta
- Asegúrate de haber copiado todos los 16 caracteres
- Verifica que la verificación en 2 pasos esté activada

### Error: "Connection timeout"
- Verifica tu conexión a internet
- Gmail puede bloquear conexiones desde ciertas IPs
- Considera usar SendGrid como alternativa

### Los correos no llegan
- Revisa la carpeta de spam
- Verifica que el correo esté bien escrito
- Revisa los logs del servidor para ver errores

### "Servicio de correo no configurado"
- Verifica que el archivo `.env` existe en `api/Api/`
- Verifica que las variables `EMAIL_USER` y `EMAIL_PASSWORD` estén correctas
- Reinicia el servidor después de crear/modificar `.env`

---

## 📝 Notas Importantes

- **Gmail:** Limitado a ~500 emails/día en cuentas personales
- **Producción:** Para producción, considera usar SendGrid o Mailgun
- **Seguridad:** Nunca subas el archivo `.env` al repositorio
- **Pruebas:** Puedes usar tu propio correo Gmail para pruebas

---

## 🎉 ¡Listo!

Una vez configurado, cada vez que un usuario solicite recuperación de contraseña, recibirá automáticamente un correo con el código de 6 dígitos.

