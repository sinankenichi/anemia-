# ✅ Solución Completa - Sistema de Correo Funcionando

## 🎯 Objetivo

Configurar el sistema de correo para que funcione **100%** y envíe correos automáticamente.

## 🚀 Método Rápido (Recomendado)

### Opción 1: Script Automatizado (MÁS FÁCIL)

Ejecuta este comando en la terminal:

```bash
cd "D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api"
npm run config-correo
```

El script te guiará paso a paso:
1. Te pedirá tu correo de Gmail
2. Te mostrará cómo obtener la contraseña de aplicación
3. Te pedirá que pegues la contraseña
4. Guardará el archivo automáticamente
5. Verificará que funcione

**¡Es la forma más fácil!**

### Opción 2: Manual

Si prefieres hacerlo manualmente:

1. **Obtén tu contraseña de aplicación:**
   - Ve a: https://myaccount.google.com/apppasswords
   - Selecciona: Correo → Otro → "Inspira Salud API"
   - Copia la contraseña de 16 caracteres

2. **Edita el archivo .env:**
   - Ubicación: `api/Api/.env`
   - Reemplaza `REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION` con tu contraseña real

3. **Verifica:**
   ```bash
   npm run test-correo
   ```

## 📋 Estado Actual del Sistema

### ✅ Lo que ya funciona:

1. ✅ Generación de códigos de 6 dígitos
2. ✅ Guardado en base de datos
3. ✅ Endpoint `/forgot-password` funcionando
4. ✅ Sistema de correo implementado

### ⚠️ Lo que falta:

1. ⚠️ Configurar credenciales de Gmail en `.env`

## 🔧 Solución Paso a Paso

### Paso 1: Obtener Contraseña de Aplicación

1. **Abre tu navegador**
2. **Ve a:** https://myaccount.google.com/apppasswords
3. Si no ves la opción:
   - Ve a: https://myaccount.google.com/security
   - Activa "Verificación en 2 pasos"
   - Luego vuelve a apppasswords
4. **Selecciona:**
   - **Aplicación:** Correo
   - **Dispositivo:** Otro (nombre personalizado)
   - **Nombre:** `Inspira Salud API`
   - Haz clic en **"Generar"**
5. **Copia la contraseña de 16 caracteres**

### Paso 2: Configurar (Elige uno)

**Opción A: Script Automatizado (Recomendado)**
```bash
npm run config-correo
```

**Opción B: Manual**
1. Abre `api/Api/.env` con Bloc de notas
2. Reemplaza la línea:
   ```env
   EMAIL_PASSWORD=REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION
   ```
3. Con:
   ```env
   EMAIL_PASSWORD=tu_contraseña_de_16_caracteres
   ```
4. Guarda el archivo

### Paso 3: Verificar

```bash
npm run test-correo
```

Deberías ver:
```
✅ EMAIL_PASSWORD configurado (16 caracteres)
✅ Conexión exitosa con Gmail
✅ El servicio de correo está listo para enviar mensajes
```

### Paso 4: Probar

1. Desde la app Android, ve a "Recuperar Contraseña"
2. Ingresa un correo registrado
3. Revisa los logs del servidor, deberías ver:
   ```
   ✅ Código enviado por correo a: correo@ejemplo.com
   ```
4. Revisa tu correo, deberías recibir el código ✨

## 🆘 Si No Funciona

### Error: "Invalid login"

**Causa:** Contraseña incorrecta o usando contraseña normal

**Solución:**
1. Genera una NUEVA contraseña de aplicación
2. Asegúrate de usar la contraseña de aplicación (16 caracteres), NO tu contraseña normal
3. Verifica que la verificación en 2 pasos esté activada

### Error: "Servicio de correo no configurado"

**Causa:** El archivo .env no existe o tiene valores por defecto

**Solución:**
1. Ejecuta: `npm run config-correo`
2. O edita manualmente el archivo `.env`

### El código no llega por correo

**Solución:**
1. Revisa la carpeta de spam
2. Verifica los logs del servidor
3. Ejecuta: `npm run test-correo` para verificar la configuración

## 📊 Funcionamiento Actual

**Sin correo configurado:**
- ✅ Código se genera
- ✅ Código se guarda en BD
- ⚠️ Código se muestra en logs del servidor (para desarrollo)
- ❌ Correo NO se envía

**Con correo configurado:**
- ✅ Código se genera
- ✅ Código se guarda en BD
- ✅ Correo se envía automáticamente
- ✅ Usuario recibe el código por correo

## 🎉 Comandos Útiles

```bash
# Configurar correo (interactivo)
npm run config-correo

# Verificar configuración
npm run test-correo

# Iniciar servidor
npm run dev
```

## ✅ Checklist Final

- [ ] Contraseña de aplicación obtenida de Gmail
- [ ] Archivo `.env` configurado correctamente
- [ ] `npm run test-correo` muestra "✅ Conexión exitosa"
- [ ] Servidor muestra "✅ Servicio de correo configurado correctamente"
- [ ] Prueba desde la app funciona y llega el correo

---

**Una vez completado, el sistema funcionará al 100%** 🎉

