# 📧 Configuración de Envío de Correos Electrónicos

Este proyecto usa **Nodemailer con Gmail SMTP** para enviar códigos de verificación de forma gratuita.

## 🚀 Configuración Rápida (Gmail - Gratis)

### Paso 1: Instalar dependencias
```bash
cd api/Api
npm install nodemailer
```

### Paso 2: Configurar Gmail

1. **Activar Verificación en 2 Pasos:**
   - Ve a: https://myaccount.google.com/security
   - Activa "Verificación en 2 pasos" si no está activada

2. **Generar Contraseña de Aplicación:**
   - Ve a: https://myaccount.google.com/apppasswords
   - Selecciona "Correo" y "Otro (nombre personalizado)"
   - Escribe "Inspira Salud API"
   - Copia la contraseña de 16 caracteres generada

### Paso 3: Configurar variables de entorno

Crea un archivo `.env` en la carpeta `api/Api/`:

```env
EMAIL_USER=tu_email@gmail.com
EMAIL_PASSWORD=la_contraseña_de_16_caracteres_generada
```

### Paso 4: Cargar variables de entorno

Instala `dotenv`:
```bash
npm install dotenv
```

Y agrega al inicio de `index.js`:
```javascript
require('dotenv').config();
```

## 🔄 Alternativas Gratuitas

### Opción 1: SendGrid (Recomendado para producción)
- **Gratis:** 100 emails/día
- **Registro:** https://sendgrid.com/
- **Ventaja:** Más confiable, mejor para producción

### Opción 2: Mailgun
- **Gratis:** 5,000 emails/mes
- **Registro:** https://www.mailgun.com/
- **Ventaja:** Gran cantidad de emails gratis

### Opción 3: Brevo (Sendinblue)
- **Gratis:** 300 emails/día
- **Registro:** https://www.brevo.com/
- **Ventaja:** Interfaz fácil, buen soporte

## 📝 Notas Importantes

- **Gmail:** Limitado a ~500 emails/día en cuentas personales
- **Producción:** Considera usar SendGrid o Mailgun para mejor confiabilidad
- **Seguridad:** Nunca subas el archivo `.env` al repositorio (ya está en .gitignore)

## 🧪 Probar el Envío

Puedes probar el servicio ejecutando:
```javascript
const emailService = require('./emailService');
emailService.verificarConfiguracion();
```

