# 🚀 Guía Rápida - Crear Archivo .env

## ⚠️ Problema Actual

Los logs muestran:
```
⚠️ Error al enviar correo: Servicio de correo no configurado
```

Esto significa que **falta el archivo `.env`** con tus credenciales de Gmail.

## ✅ Solución Rápida

### Paso 1: Obtener Contraseña de Aplicación

1. Ve a: **https://myaccount.google.com/apppasswords**
2. Si no ves la opción, primero activa "Verificación en 2 pasos"
3. Selecciona:
   - **Aplicación:** Correo
   - **Dispositivo:** Otro (nombre personalizado)
   - **Nombre:** `Inspira Salud API`
4. **Copia la contraseña de 16 caracteres** (ejemplo: `abcd efgh ijkl mnop`)

### Paso 2: Crear Archivo .env

1. Abre el Bloc de notas o cualquier editor de texto
2. Copia y pega esto:

```env
EMAIL_USER=kenisstore18@gmail.com
EMAIL_PASSWORD=TU_CONTRASEÑA_DE_16_CARACTERES_AQUI
```

3. **Reemplaza** `TU_CONTRASEÑA_DE_16_CARACTERES_AQUI` con la contraseña que copiaste
4. Guarda el archivo como: **`.env`** (con el punto al inicio)
5. **Ubicación:** `D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api\.env`

### Paso 3: Verificar

El servidor debería reiniciarse automáticamente. Deberías ver:

```
✅ Servicio de correo configurado correctamente.
```

Luego, cuando pruebes recuperar contraseña, verás:

```
✅ Código enviado por correo a: kenisstore18@gmail.com
```

## 📝 Ejemplo Completo

Si tu contraseña de aplicación es `abcd efgh ijkl mnop`, tu archivo `.env` debería verse así:

```env
EMAIL_USER=kenisstore18@gmail.com
EMAIL_PASSWORD=abcd efgh ijkl mnop
```

## 🧪 Probar

Después de crear el archivo `.env`:

1. El servidor se reiniciará automáticamente
2. Prueba desde la app: "Recuperar Contraseña"
3. Revisa tu correo: `kenisstore18@gmail.com`
4. Deberías recibir el código por correo ✨

## ⚠️ Notas Importantes

- El archivo debe llamarse exactamente **`.env`** (con punto al inicio)
- No debe tener extensión (no `.env.txt`)
- La contraseña puede tener espacios o no, ambos funcionan
- El archivo `.env` NO se sube al repositorio (está protegido)

## 🆘 Si No Funciona

1. Verifica que el archivo se llame exactamente `.env`
2. Verifica que esté en la carpeta correcta: `api/Api/`
3. Verifica que las credenciales sean correctas
4. Reinicia el servidor manualmente: `npm run dev`

