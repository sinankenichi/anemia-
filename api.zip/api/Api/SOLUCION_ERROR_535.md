# 🔧 Solución: Error 535 - Invalid Login (Gmail)

## ❌ Error Actual

```
❌ Error en la configuración del correo: Invalid login: 535-5.7.8 
Username and Password not accepted.
```

Este error significa que **Gmail rechazó las credenciales**. 

## 🔍 Causas Comunes

1. **Usando contraseña normal en lugar de contraseña de aplicación**
2. **Contraseña de aplicación incorrecta o mal copiada**
3. **Verificación en 2 pasos no activada**
4. **Espacios extra en el archivo .env**
5. **Formato incorrecto del archivo .env**

## ✅ Solución Paso a Paso

### Paso 1: Verificar Verificación en 2 Pasos

1. Ve a: https://myaccount.google.com/security
2. Verifica que **"Verificación en 2 pasos"** esté **ACTIVADA**
3. Si no está activada, actívala primero

### Paso 2: Generar Nueva Contraseña de Aplicación

1. Ve a: https://myaccount.google.com/apppasswords
2. Si no ves esta opción, primero activa "Verificación en 2 pasos"
3. Selecciona:
   - **Aplicación:** Correo
   - **Dispositivo:** Otro (nombre personalizado)
   - **Nombre:** `Inspira Salud API`
4. Haz clic en **"Generar"**
5. **Copia la contraseña de 16 caracteres** que aparece
   - Ejemplo: `abcd efgh ijkl mnop`
   - O sin espacios: `abcdefghijklmnop`

### Paso 3: Editar el Archivo .env Correctamente

1. Abre el archivo `.env` en un editor de texto simple (Bloc de notas)
2. **Borra todo el contenido**
3. Copia y pega esto (REEMPLAZA con tus datos reales):

```env
EMAIL_USER=kenisstore18@gmail.com
EMAIL_PASSWORD=TU_CONTRASEÑA_AQUI
```

4. **Reemplaza `TU_CONTRASEÑA_AQUI`** con la contraseña de 16 caracteres que copiaste
5. **IMPORTANTE:**
   - No dejes espacios antes o después del `=`
   - No pongas comillas alrededor de los valores
   - Puedes usar la contraseña con espacios o sin espacios (ambos funcionan)
   - No agregues líneas vacías al final

### Paso 4: Ejemplos Correctos

**✅ CORRECTO (con espacios):**
```env
EMAIL_USER=kenisstore18@gmail.com
EMAIL_PASSWORD=abcd efgh ijkl mnop
```

**✅ CORRECTO (sin espacios):**
```env
EMAIL_USER=kenisstore18@gmail.com
EMAIL_PASSWORD=abcdefghijklmnop
```

**❌ INCORRECTO (con comillas):**
```env
EMAIL_USER="kenisstore18@gmail.com"
EMAIL_PASSWORD="abcd efgh ijkl mnop"
```

**❌ INCORRECTO (con espacios alrededor del =):**
```env
EMAIL_USER = kenisstore18@gmail.com
EMAIL_PASSWORD = abcd efgh ijkl mnop
```

### Paso 5: Guardar y Verificar

1. **Guarda el archivo** (Ctrl+S)
2. **Cierra el editor**
3. El servidor debería reiniciarse automáticamente
4. Deberías ver:

```
✅ Servidor de correo listo para enviar mensajes
✅ Servicio de correo configurado correctamente.
```

## 🧪 Probar Nuevamente

1. Desde la app, prueba "Recuperar Contraseña"
2. Ingresa: `kenisstore18@gmail.com`
3. Revisa los logs del servidor, deberías ver:

```
✅ Código enviado por correo a: kenisstore18@gmail.com
```

4. Revisa tu correo, deberías recibir el código

## 🔍 Verificación Adicional

Si aún no funciona, verifica:

1. **El correo es correcto:**
   - Debe ser exactamente: `kenisstore18@gmail.com`
   - Sin espacios antes o después

2. **La contraseña es correcta:**
   - Debe ser la contraseña de aplicación (16 caracteres)
   - NO tu contraseña normal de Gmail
   - Copiada completa sin caracteres faltantes

3. **El archivo .env está en la ubicación correcta:**
   - `D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api\.env`

4. **Formato del archivo:**
   - Sin líneas vacías al inicio
   - Sin espacios antes o después del `=`
   - Sin comillas alrededor de los valores

## 🆘 Si Sigue Sin Funcionar

1. **Genera una nueva contraseña de aplicación** (las anteriores pueden haberse invalidado)
2. **Verifica que la verificación en 2 pasos esté activada**
3. **Prueba sin espacios** en la contraseña
4. **Reinicia el servidor manualmente:** `npm run dev`

## 📝 Nota Importante

- **NUNCA uses tu contraseña normal de Gmail**
- **SIEMPRE usa una contraseña de aplicación** generada específicamente para esto
- Las contraseñas de aplicación son más seguras y están diseñadas para este propósito

