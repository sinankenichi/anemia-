// Script de prueba rápida para verificar que la API está accesible
const http = require('http');

const HOST = '192.168.100.5'; // Cambia esto por tu IP
const PORT = 3000;

console.log(`🔍 Probando conexión a http://${HOST}:${PORT}...\n`);

// Probar endpoint de salud
const options = {
  hostname: HOST,
  port: PORT,
  path: '/health',
  method: 'GET',
  timeout: 5000
};

const req = http.request(options, (res) => {
  console.log(`✅ Conexión exitosa!`);
  console.log(`   Status: ${res.statusCode}`);
  console.log(`   Headers:`, res.headers);
  
  let data = '';
  res.on('data', (chunk) => {
    data += chunk;
  });
  
  res.on('end', () => {
    console.log(`   Response:`, data);
    console.log(`\n✅ La API está funcionando correctamente!`);
    process.exit(0);
  });
});

req.on('error', (e) => {
  console.error(`❌ Error de conexión: ${e.message}`);
  console.log(`\n⚠️  Posibles causas:`);
  console.log(`   1. La API no está corriendo`);
  console.log(`   2. La IP es incorrecta (actual: ${HOST})`);
  console.log(`   3. El firewall está bloqueando el puerto ${PORT}`);
  console.log(`   4. No estás en la misma red`);
  process.exit(1);
});

req.on('timeout', () => {
  console.error(`❌ Timeout: No se pudo conectar en 5 segundos`);
  req.destroy();
  process.exit(1);
});

req.end();

