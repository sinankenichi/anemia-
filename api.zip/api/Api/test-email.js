// Script de prueba para verificar el servicio de correo
const emailService = require('./emailService');

async function testEmailService() {
  console.log('\n🧪 Probando servicio de correo...\n');
  
  // Verificar configuración
  console.log('1. Verificando configuración...');
  const isConfigured = await emailService.verificarConfiguracion();
  
  if (isConfigured) {
    console.log('   ✅ Servicio de correo configurado correctamente\n');
    console.log('2. Probando envío de correo de prueba...');
    
    try {
      // Usar un correo de prueba (no se enviará realmente sin credenciales válidas)
      await emailService.enviarCodigoVerificacion('test@example.com', '123456');
      console.log('   ✅ Correo enviado exitosamente\n');
    } catch (error) {
      console.log('   ⚠️ Error al enviar:', error.message);
      console.log('   (Esto es normal si las credenciales no están configuradas)\n');
    }
  } else {
    console.log('   ⚠️ Servicio de correo NO configurado\n');
    console.log('   Para configurarlo:');
    console.log('   1. Crea un archivo .env en esta carpeta');
    console.log('   2. Agrega:');
    console.log('      EMAIL_USER=tu_email@gmail.com');
    console.log('      EMAIL_PASSWORD=tu_contraseña_de_aplicacion');
    console.log('   3. Obtén la contraseña en: https://myaccount.google.com/apppasswords\n');
  }
  
  console.log('✅ Prueba completada\n');
}

testEmailService().catch(console.error);

