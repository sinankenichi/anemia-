# 📝 Cómo Abrir y Editar el Archivo .env

## 🎯 Objetivo

Reemplazar `REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION` con tu contraseña real de Gmail.

## 📋 Pasos Detallados

### Paso 1: Obtener Contraseña de Aplicación

1. **Abre tu navegador** (Chrome, Edge, Firefox, etc.)
2. **Ve a:** https://myaccount.google.com/apppasswords
3. Si no ves la opción:
   - Primero ve a: https://myaccount.google.com/security
   - Activa "Verificación en 2 pasos"
   - Luego vuelve a apppasswords
4. **Selecciona:**
   - **Aplicación:** Correo
   - **Dispositivo:** Otro (nombre personalizado)
   - **Nombre:** `Inspira Salud API`
   - Haz clic en **"Generar"**
5. **Copia la contraseña de 16 caracteres** que aparece
   - Ejemplo: `abcd efgh ijkl mnop`
   - O sin espacios: `abcdefghijklmnop`
   - **¡GUÁRDALA!** No podrás verla de nuevo

### Paso 2: Abrir el Archivo .env

**Opción A: Desde el Explorador de Archivos**

1. Abre el **Explorador de Archivos de Windows**
2. Ve a la barra de direcciones y copia/pega:
   ```
   D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api
   ```
3. Presiona **Enter**
4. Si no ves el archivo `.env`:
   - Ve a la pestaña **"Vista"**
   - Marca **"Elementos ocultos"**
   - Ahora deberías ver `.env`
5. **Haz clic derecho** en `.env`
6. Selecciona **"Abrir con"** → **"Bloc de notas"**

**Opción B: Desde VS Code (si lo tienes)**

1. Abre VS Code
2. Archivo → Abrir carpeta
3. Navega a: `D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api`
4. Busca `.env` en el explorador de archivos
5. Haz doble clic para abrirlo

### Paso 3: Editar el Archivo

1. **Deberías ver algo como:**
   ```env
   EMAIL_USER=kenisstore18@gmail.com
   EMAIL_PASSWORD=REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION
   ```

2. **Selecciona** el texto `REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION`
   - Puedes hacer clic y arrastrar para seleccionarlo
   - O hacer doble clic en la palabra

3. **Borra** el texto seleccionado (presiona Delete o Backspace)

4. **Pega** tu contraseña de aplicación (Ctrl+V)
   - La que copiaste en el Paso 1

5. **Debería quedar así** (ejemplo):
   ```env
   EMAIL_USER=kenisstore18@gmail.com
   EMAIL_PASSWORD=abcd efgh ijkl mnop
   ```

6. **IMPORTANTE:**
   - ✅ No dejes espacios antes o después del `=`
   - ✅ No pongas comillas alrededor de los valores
   - ✅ No agregues líneas vacías al final
   - ✅ La contraseña puede tener espacios o no (ambos funcionan)

### Paso 4: Guardar

1. Presiona **Ctrl+S** para guardar
2. O ve a **Archivo** → **Guardar**
3. **Cierra** el Bloc de notas

### Paso 5: Verificar

El servidor debería reiniciarse automáticamente. Deberías ver en los logs:

```
✅ Servidor de correo listo para enviar mensajes
✅ Servicio de correo configurado correctamente.
```

Si no se reinicia automáticamente, ejecuta:
```bash
cd "D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api"
npm run dev
```

## 🧪 Probar que Funciona

Ejecuta este comando:
```bash
cd "D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api"
node test-config.js
```

Deberías ver:
```
✅ EMAIL_PASSWORD configurado (16 caracteres)
✅ Conexión exitosa con Gmail
✅ El servicio de correo está listo para enviar mensajes
```

## ⚠️ Errores Comunes

### "No encuentro el archivo .env"
- **Solución:** Activa "Mostrar archivos ocultos" en el Explorador de Archivos
- O busca directamente en: `D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api`

### "Sigue diciendo que no está configurado"
- Verifica que guardaste el archivo (Ctrl+S)
- Verifica que no hay espacios antes o después del `=`
- Verifica que la contraseña tiene 16 caracteres
- Reinicia el servidor manualmente

### "Error 535 - Invalid login"
- Estás usando tu contraseña normal de Gmail
- **Solución:** Debes usar una **contraseña de aplicación** (16 caracteres)
- Genera una nueva en: https://myaccount.google.com/apppasswords

## 📝 Ejemplo Visual

**ANTES (incorrecto):**
```env
EMAIL_USER=kenisstore18@gmail.com
EMAIL_PASSWORD=REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION
```

**DESPUÉS (correcto):**
```env
EMAIL_USER=kenisstore18@gmail.com
EMAIL_PASSWORD=abcd efgh ijkl mnop
```

---

**Una vez completado, los correos se enviarán automáticamente** ✨

