# ✅ Archivo .env Creado - Instrucciones Finales

## 📋 Estado Actual

✅ **Archivo `.env` creado exitosamente** en:
```
D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api\.env
```

## ⚠️ Acción Requerida

El archivo `.env` tiene valores de ejemplo. Necesitas **completarlo con tus credenciales reales**.

### Paso 1: Obtener Contraseña de Aplicación de Gmail

1. **Ve a:** https://myaccount.google.com/apppasswords
2. Si no ves la opción, primero activa "Verificación en 2 pasos"
3. Selecciona:
   - **Aplicación:** Correo
   - **Dispositivo:** Otro (nombre personalizado)
   - **Nombre:** `Inspira Salud API`
4. **Copia la contraseña de 16 caracteres** que aparece

### Paso 2: Editar el Archivo .env

1. Abre el archivo `.env` en cualquier editor de texto:
   - Bloc de notas
   - Notepad++
   - VS Code
   - Cualquier editor

2. Deberías ver esto:
   ```env
   EMAIL_USER=kenisstore18@gmail.com
   EMAIL_PASSWORD=REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION
   ```

3. **Reemplaza** `REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION` con tu contraseña de aplicación

4. **Ejemplo final** (si tu contraseña es `abcd efgh ijkl mnop`):
   ```env
   EMAIL_USER=kenisstore18@gmail.com
   EMAIL_PASSWORD=abcd efgh ijkl mnop
   ```

5. **Guarda el archivo**

### Paso 3: Verificar

El servidor debería reiniciarse automáticamente. Deberías ver en los logs:

```
✅ Servicio de correo configurado correctamente.
```

Luego, cuando pruebes recuperar contraseña desde la app, verás:

```
✅ Código enviado por correo a: kenisstore18@gmail.com
```

Y recibirás el correo con el código de verificación ✨

## 🧪 Probar Ahora

1. Completa el archivo `.env` con tu contraseña real
2. Guarda el archivo
3. El servidor se reiniciará automáticamente
4. Prueba desde la app: "Recuperar Contraseña"
5. Revisa tu correo: `kenisstore18@gmail.com`

## 📝 Notas

- El archivo `.env` ya está creado, solo necesitas editarlo
- La contraseña puede tener espacios o no, ambos funcionan
- El archivo está protegido y NO se sube al repositorio

## 🆘 Si Tienes Problemas

1. Verifica que el archivo se llame exactamente `.env` (con punto)
2. Verifica que esté en: `api/Api/.env`
3. Verifica que las credenciales sean correctas
4. Reinicia el servidor: `npm run dev`

---

**Una vez completado, los correos se enviarán automáticamente** 🎉

