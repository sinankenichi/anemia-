// =====================================================
// Módulo de Seguridad - Cifrado y JWT
// =====================================================

const crypto = require("crypto");
const jwt = require("jsonwebtoken");

// Configuración
const JWT_SECRET = process.env.JWT_SECRET || "tu_secreto_super_seguro_cambiar_en_produccion";
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "24h";
const SALT_ROUNDS = 10; // Para bcrypt (si se implementa)

/**
 * Genera un hash SHA-256 de una contraseña con salt
 * NOTA: Para producción, usar bcrypt o argon2
 */
function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto
    .pbkdf2Sync(password, salt, 10000, 64, "sha512")
    .toString("hex");
  return `${salt}:${hash}`;
}

/**
 * Verifica una contraseña contra un hash
 */
function verifyPassword(password, hash) {
  if (!hash || !hash.includes(":")) {
    return false; // Hash inválido o formato antiguo
  }
  
  const [salt, originalHash] = hash.split(":");
  const hashToVerify = crypto
    .pbkdf2Sync(password, salt, 10000, 64, "sha512")
    .toString("hex");
  
  return hashToVerify === originalHash;
}

/**
 * Genera un token JWT para un usuario
 */
function generateToken(userId, email, esAdmin = false) {
  const payload = {
    userId,
    email,
    esAdmin,
    iat: Math.floor(Date.now() / 1000), // Issued at
  };
  
  return jwt.sign(payload, JWT_SECRET, {
    expiresIn: JWT_EXPIRES_IN,
  });
}

/**
 * Verifica y decodifica un token JWT
 */
function verifyToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    if (error.name === "TokenExpiredError") {
      throw new Error("Token expirado");
    } else if (error.name === "JsonWebTokenError") {
      throw new Error("Token inválido");
    } else {
      throw new Error("Error al verificar token");
    }
  }
}

/**
 * Middleware de autenticación para rutas protegidas
 */
function authenticateToken(req, res, next) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1]; // Bearer TOKEN
  
  if (!token) {
    return res.status(401).json({
      success: false,
      error: "Token de autenticación requerido",
      code: "AUTH_TOKEN_MISSING"
    });
  }
  
  try {
    const decoded = verifyToken(token);
    req.user = decoded; // Agregar información del usuario al request
    next();
  } catch (error) {
    return res.status(403).json({
      success: false,
      error: error.message,
      code: "AUTH_TOKEN_INVALID"
    });
  }
}

/**
 * Middleware para verificar si el usuario es administrador
 */
function requireAdmin(req, res, next) {
  if (!req.user || !req.user.esAdmin) {
    return res.status(403).json({
      success: false,
      error: "Acceso denegado. Se requieren permisos de administrador",
      code: "ADMIN_REQUIRED"
    });
  }
  next();
}

/**
 * Genera un token seguro para recuperación de contraseña
 */
function generateRecoveryToken() {
  return crypto.randomBytes(32).toString("hex");
}

/**
 * Manejo centralizado de errores de seguridad
 */
function handleSecurityError(error, res) {
  console.error("❌ Error de seguridad:", error);
  
  const errorMessages = {
    "Token expirado": {
      status: 401,
      message: "Su sesión ha expirado. Por favor, inicie sesión nuevamente",
      code: "TOKEN_EXPIRED"
    },
    "Token inválido": {
      status: 403,
      message: "Token de autenticación inválido",
      code: "TOKEN_INVALID"
    },
    "Error al verificar token": {
      status: 500,
      message: "Error al procesar la autenticación",
      code: "AUTH_ERROR"
    }
  };
  
  const errorInfo = errorMessages[error.message] || {
    status: 500,
    message: "Error de seguridad",
    code: "SECURITY_ERROR"
  };
  
  return res.status(errorInfo.status).json({
    success: false,
    error: errorInfo.message,
    code: errorInfo.code
  });
}

module.exports = {
  hashPassword,
  verifyPassword,
  generateToken,
  verifyToken,
  authenticateToken,
  requireAdmin,
  generateRecoveryToken,
  handleSecurityError,
  JWT_SECRET,
  JWT_EXPIRES_IN
};

