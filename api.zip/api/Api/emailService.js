// =====================================================
// Servicio de Envío de Correos Electrónicos
// =====================================================
// Usa Nodemailer con Gmail SMTP (gratis)
// Alternativa: SendGrid, Mailgun, Brevo (Sendinblue)
// =====================================================

const nodemailer = require('nodemailer');

// Configuración del transporter de Gmail
// IMPORTANTE: Necesitas crear una "Contraseña de aplicación" en tu cuenta de Gmail
// Pasos: Google Account > Seguridad > Verificación en 2 pasos > Contraseñas de aplicaciones
const emailUser = process.env.EMAIL_USER || '';
const emailPassword = process.env.EMAIL_PASSWORD || '';

// Solo crear transporter si las credenciales están configuradas
let transporter = null;
const passwordIsDefault = !emailPassword || 
  emailPassword === 'tu_contraseña_aplicacion' || 
  emailPassword.includes('REEMPLAZA') ||
  emailPassword.includes('REEMPLACE');

if (emailUser && emailPassword && emailUser !== 'tu_email@gmail.com' && !passwordIsDefault) {
  transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
      user: emailUser,
      pass: emailPassword
    }
  });
}

/**
 * Envía un código de verificación por correo electrónico
 * @param {string} correo - Correo del destinatario
 * @param {string} codigo - Código de 6 dígitos
 * @returns {Promise<boolean>} - true si se envió correctamente
 */
async function enviarCodigoVerificacion(correo, codigo) {
  if (!transporter) {
    throw new Error('Servicio de correo no configurado. Configura EMAIL_USER y EMAIL_PASSWORD en variables de entorno.');
  }
  
  try {
    const emailUser = process.env.EMAIL_USER || '';
    const mailOptions = {
      from: `"Inspira Salud" <${emailUser}>`,
      to: correo,
      subject: 'Código de Verificación - Recuperación de Contraseña',
      html: `
        <!DOCTYPE html>
        <html>
        <head>
          <meta charset="UTF-8">
          <style>
            body {
              font-family: Arial, sans-serif;
              line-height: 1.6;
              color: #333;
              max-width: 600px;
              margin: 0 auto;
              padding: 20px;
            }
            .container {
              background-color: #ffffff;
              border-radius: 10px;
              padding: 30px;
              box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            }
            .header {
              text-align: center;
              margin-bottom: 30px;
            }
            .logo {
              font-size: 24px;
              font-weight: bold;
              color: #FF4081;
            }
            .code-box {
              background-color: #f5f5f5;
              border: 2px dashed #FF4081;
              border-radius: 8px;
              padding: 20px;
              text-align: center;
              margin: 30px 0;
            }
            .code {
              font-size: 32px;
              font-weight: bold;
              color: #FF4081;
              letter-spacing: 5px;
              font-family: 'Courier New', monospace;
            }
            .footer {
              margin-top: 30px;
              padding-top: 20px;
              border-top: 1px solid #eee;
              font-size: 12px;
              color: #666;
              text-align: center;
            }
            .warning {
              background-color: #fff3cd;
              border-left: 4px solid #ffc107;
              padding: 15px;
              margin: 20px 0;
              border-radius: 4px;
            }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Inspira Salud</div>
            </div>
            
            <h2>Recuperación de Contraseña</h2>
            
            <p>Hola,</p>
            
            <p>Has solicitado recuperar tu contraseña. Utiliza el siguiente código de verificación:</p>
            
            <div class="code-box">
              <div class="code">${codigo}</div>
            </div>
            
            <div class="warning">
              <strong>⚠️ Importante:</strong> Este código expira en 15 minutos. No compartas este código con nadie.
            </div>
            
            <p>Si no solicitaste este código, puedes ignorar este correo de forma segura.</p>
            
            <div class="footer">
              <p>Este es un correo automático, por favor no respondas.</p>
              <p>&copy; ${new Date().getFullYear()} Inspira Salud - App educativa sobre anemia y nutrición</p>
            </div>
          </div>
        </body>
        </html>
      `,
      text: `
        Código de Verificación - Recuperación de Contraseña
        
        Tu código de verificación es: ${codigo}
        
        Este código expira en 15 minutos.
        
        Si no solicitaste este código, puedes ignorar este correo.
      `
    };

    const info = await transporter.sendMail(mailOptions);
    console.log('✅ Correo enviado exitosamente:', info.messageId);
    return true;
  } catch (error) {
    console.error('❌ Error al enviar correo:', error.message);
    throw error;
  }
}

/**
 * Verifica la configuración del servicio de correo
 * @returns {Promise<boolean>} - true si la configuración es válida
 */
async function verificarConfiguracion() {
  if (!transporter) {
    return false;
  }
  
  try {
    await transporter.verify();
    console.log('✅ Servidor de correo listo para enviar mensajes');
    return true;
  } catch (error) {
    console.error('❌ Error en la configuración del correo:', error.message);
    return false;
  }
}

module.exports = {
  enviarCodigoVerificacion,
  verificarConfiguracion
};

