// =====================================================
// API Completa para App de Salud - Anemia
// =====================================================
// Endpoints:
// - POST /registro - Registrar nuevo usuario
// - POST /login - Iniciar sesión
// - POST /forgot-password - Solicitar recuperación de contraseña
// - POST /change-password - Cambiar contraseña
// - POST /cuestionario - Enviar cuestionario
// =====================================================

// Cargar variables de entorno si existe dotenv
try {
  require('dotenv').config();
} catch (e) {
  console.log('⚠️ dotenv no instalado. Usando variables de entorno del sistema o valores por defecto.');
}

const express = require("express");
const mysql = require("mysql2");
const bodyParser = require("body-parser");
const cors = require("cors");
const crypto = require("crypto");
const os = require("os");
const emailService = require("./emailService");

const app = express();
const PUERTO = 3000;

// Configurar trust proxy para obtener la IP real del cliente
app.set('trust proxy', true);

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Middleware de logging para todas las peticiones (después de bodyParser para poder leer el body)
app.use((req, res, next) => {
  const timestamp = new Date().toISOString();
  const clientIP = req.ip || req.connection.remoteAddress || req.socket.remoteAddress || 'unknown';
  console.log(`\n📥 [${timestamp}] ${req.method} ${req.path}`);
  console.log(`   IP: ${clientIP}`);
  if (req.body && Object.keys(req.body).length > 0) {
    console.log(`   Body: ${JSON.stringify(req.body)}`);
  }
  next();
});

// Configuración de pool de conexiones a la base de datos (más robusto que createConnection)
const pool = mysql.createPool({
  host: "localhost",
  database: "login_db",
  port: 3306,
  user: "root",
  password: "123456789",
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0,
  enableKeepAlive: true,
  keepAliveInitialDelay: 0
});

// Promisificar el pool para usar async/await
const promisePool = pool.promise();

// =====================================================
// FUNCIONES AUXILIARES
// =====================================================

// Función para calcular el score de una encuesta
// Cada respuesta puede tener un valor numérico (1-5) o texto
// Por ahora, asumimos que las respuestas son valores numéricos o se convierten a puntos
function calcularScore(preguntas) {
  let score = 0;
  
  for (const respuesta of preguntas) {
    // Si la respuesta es un número, sumarlo directamente
    const num = parseInt(respuesta);
    if (!isNaN(num) && num > 0) {
      score += num;
    } else {
      // Si es texto, intentar convertir valores comunes a puntos
      const respuestaLower = respuesta.toLowerCase().trim();
      if (respuestaLower.includes("siempre") || respuestaLower.includes("muy bueno") || respuestaLower.includes("excelente")) {
        score += 5;
      } else if (respuestaLower.includes("frecuentemente") || respuestaLower.includes("bueno")) {
        score += 4;
      } else if (respuestaLower.includes("a veces") || respuestaLower.includes("regular")) {
        score += 3;
      } else if (respuestaLower.includes("rara vez") || respuestaLower.includes("malo")) {
        score += 2;
      } else if (respuestaLower.includes("nunca") || respuestaLower.includes("muy malo")) {
        score += 1;
      } else {
        // Por defecto, dar 1 punto si hay respuesta
        score += 1;
      }
    }
  }
  
  return score;
}

// Función para verificar la conexión
async function verificarConexion() {
  try {
    const [rows] = await promisePool.query("SELECT 1 as test");
    console.log("✅ Conexión a base de datos verificada exitosamente");
    return true;
  } catch (error) {
    console.error("❌ Error al verificar conexión a base de datos:", error.message);
    return false;
  }
}

// Obtener la IP local para mostrar en los logs
function getLocalIP() {
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    for (const iface of interfaces[name]) {
      // Ignorar direcciones internas y no IPv4
      if (iface.family === "IPv4" && !iface.internal) {
        return iface.address;
      }
    }
  }
  return "localhost";
}

// Iniciar servidor - escuchar en todas las interfaces (0.0.0.0) para ser accesible desde la red
const HOST = "0.0.0.0"; // Escuchar en todas las interfaces de red
// Verificar configuración de correo al iniciar
emailService.verificarConfiguracion().then(isReady => {
  if (!isReady) {
    console.log('\n⚠️ ADVERTENCIA: El servicio de correo no está configurado correctamente.');
    console.log('   Los códigos se generarán pero NO se enviarán por correo.');
    console.log('   Revisa README_EMAIL.md para configurar el envío de correos.\n');
  } else {
    console.log('\n✅ Servicio de correo configurado correctamente.\n');
  }
});

app.listen(PUERTO, HOST, async () => {
  const localIP = getLocalIP();
  console.log("🚀 Servidor corriendo en:");
  console.log("   - Local: http://localhost:" + PUERTO);
  console.log("   - Red: http://" + localIP + ":" + PUERTO);
  console.log("   - Todas las interfaces: http://0.0.0.0:" + PUERTO);
  // Verificar conexión al iniciar
  await verificarConexion();
});

// =====================================================
// ENDPOINTS
// =====================================================

// Endpoint raíz
app.get("/", (req, res) => {
  res.send("Bienvenido a la API de Salud - Anemia");
});

// Endpoint de salud para verificar que la API y BD están funcionando
app.get("/health", async (req, res) => {
  try {
    const [rows] = await promisePool.query("SELECT 1 as test");
    res.json({
      status: "ok",
      database: "connected",
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    res.status(500).json({
      status: "error",
      database: "disconnected",
      error: error.message,
      timestamp: new Date().toISOString()
    });
  }
});

// =====================================================
// POST /registro - Registrar nuevo usuario
// =====================================================
app.post("/registro", async (req, res) => {
  console.log("📥 Datos recibidos en /registro:", JSON.stringify(req.body));

  try {
    const { nombres, apellidos, correo, contraseña, fechaNacimiento } = req.body;

    // Validar campos requeridos
    if (!nombres || !apellidos || !correo || !contraseña || !fechaNacimiento) {
      console.log("❌ Validación fallida: campos faltantes");
      return res.status(400).json({ error: "Todos los campos son requeridos (incluyendo fecha de nacimiento)" });
    }

    // Validar formato de fecha (YYYY-MM-DD)
    const fechaRegex = /^\d{4}-\d{2}-\d{2}$/;
    if (!fechaRegex.test(fechaNacimiento)) {
      console.log("❌ Validación fallida: formato de fecha inválido");
      return res.status(400).json({ error: "Formato de fecha inválido. Use YYYY-MM-DD" });
    }

    // Validar que la fecha no sea futura
    const fechaNac = new Date(fechaNacimiento);
    const hoy = new Date();
    if (fechaNac > hoy) {
      console.log("❌ Validación fallida: fecha de nacimiento futura");
      return res.status(400).json({ error: "La fecha de nacimiento no puede ser futura" });
    }

    // Validar formato de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(correo)) {
      console.log("❌ Validación fallida: formato de email inválido");
      return res.status(400).json({ error: "Formato de correo inválido" });
    }

    // Validar longitud de contraseña
    if (contraseña.length < 6) {
      console.log("❌ Validación fallida: contraseña muy corta");
      return res.status(400).json({ error: "La contraseña debe tener al menos 6 caracteres" });
    }

    // Verificar si el correo ya existe
    const checkQuery = "SELECT usu_id FROM usuarios WHERE usu_email = ?";
    const [checkResults] = await promisePool.query(checkQuery, [correo]);

    if (checkResults.length > 0) {
      console.log("❌ Correo ya registrado:", correo);
      return res.status(400).json({ error: "El correo electrónico ya está registrado" });
    }

    // Insertar nuevo usuario
    const insertQuery = "INSERT INTO usuarios (usu_nombres, usu_apellidos, usu_email, usu_password, fecha_nacimiento) VALUES (?, ?, ?, ?, ?)";
    const [insertResult] = await promisePool.query(insertQuery, [nombres, apellidos, correo, contraseña, fechaNacimiento]);

    console.log("✅ Usuario registrado exitosamente, ID:", insertResult.insertId);

    res.json({
      message: "Usuario registrado exitosamente",
      success: true,
      user: {
        id: insertResult.insertId,
        nombres: nombres,
        apellidos: apellidos,
        correo: correo,
        fechaNacimiento: fechaNacimiento
      }
    });
  } catch (error) {
    console.error("❌ Error en /registro:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// POST /login - Iniciar sesión
// =====================================================
app.post("/login", async (req, res) => {
  console.log("📥 Datos recibidos en /login:", JSON.stringify(req.body));

  try {
    const { correo, contraseña } = req.body;

    if (!correo || !contraseña) {
      console.log("❌ Validación fallida: campos faltantes");
      return res.status(400).json({ error: "Correo y contraseña son requeridos" });
    }

    const query = "SELECT usu_id, usu_nombres, usu_apellidos, usu_email, tipo_usuario FROM usuarios WHERE usu_email = ? AND usu_password = ? AND activo = 1";
    const [results] = await promisePool.query(query, [correo, contraseña]);

    if (results.length > 0) {
      const user = results[0];
      const esAdmin = user.tipo_usuario === 'admin';
      console.log("✅ Login exitoso para usuario:", correo, esAdmin ? "(ADMIN)" : "");
      res.json({
        message: "Login exitoso",
        success: true,
        user: {
          id: user.usu_id,
          nombres: user.usu_nombres,
          apellidos: user.usu_apellidos,
          correo: user.usu_email,
          esAdmin: esAdmin
        }
      });
    } else {
      console.log("❌ Login fallido: credenciales incorrectas para", correo);
      res.status(401).json({ error: "Correo o contraseña incorrectos" });
    }
  } catch (error) {
    console.error("❌ Error en /login:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// POST /forgot-password - Solicitar recuperación de contraseña
// =====================================================
app.post("/forgot-password", async (req, res) => {
  console.log("📥 Datos recibidos en /forgot-password:", JSON.stringify(req.body));

  try {
    const { correo } = req.body;

    if (!correo) {
      console.log("❌ Validación fallida: correo faltante");
      return res.status(400).json({ error: "El correo es requerido" });
    }

    // Verificar si el correo existe
    const checkQuery = "SELECT usu_id, usu_email FROM usuarios WHERE usu_email = ? AND activo = 1";
    const [checkResults] = await promisePool.query(checkQuery, [correo]);

    if (checkResults.length === 0) {
      // Por seguridad, no revelamos si el correo existe o no
      console.log("⚠️ Correo no encontrado (por seguridad no se revela)");
      return res.json({
        message: "Si el correo existe, se enviará un código de verificación",
        success: true
      });
    }

    // Generar código de 6 dígitos
    const codigo = Math.floor(100000 + Math.random() * 900000).toString();
    const fechaExpiracion = new Date();
    fechaExpiracion.setMinutes(fechaExpiracion.getMinutes() + 15); // Expira en 15 minutos

    // Eliminar códigos anteriores del usuario
    try {
      const deleteQuery = "DELETE FROM tokens_recuperacion WHERE usu_email = ?";
      await promisePool.query(deleteQuery, [correo]);
    } catch (error) {
      console.error("⚠️ Error al eliminar códigos anteriores (continuando):", error.message);
    }

    // Insertar nuevo código
    const insertQuery = "INSERT INTO tokens_recuperacion (usu_email, token, fecha_expiracion) VALUES (?, ?, ?)";
    await promisePool.query(insertQuery, [correo, codigo, fechaExpiracion]);

    console.log("✅ Código generado para", correo, ":", codigo);

    // Enviar código por correo electrónico
    let correoEnviado = false;
    try {
      await emailService.enviarCodigoVerificacion(correo, codigo);
      console.log("✅ Código enviado por correo a:", correo);
      correoEnviado = true;
    } catch (emailError) {
      // Mostrar el código de forma muy visible cuando no hay correo configurado
      console.error("\n" + "=".repeat(70));
      console.error("⚠️  CORREO NO CONFIGURADO - CÓDIGO DE VERIFICACIÓN");
      console.error("=".repeat(70));
      console.error(`📧 Correo: ${correo}`);
      console.error(`🔑 Código: ${codigo}`);
      console.error("=".repeat(70));
      console.error("⚠️  Este código está guardado en la BD pero NO se envió por correo.");
      console.error("📝 Para activar el envío de correos, configura Gmail en el archivo .env");
      console.error("=".repeat(70) + "\n");
      correoEnviado = false;
    }

    res.json({
      message: correoEnviado 
        ? "Código de verificación enviado por correo" 
        : "Código generado. Revisa los logs del servidor para ver el código.",
      success: true,
      codigo: correoEnviado ? undefined : codigo, // Solo incluir código si no se envió correo (para desarrollo)
      correo_enviado: correoEnviado
    });
  } catch (error) {
    console.error("❌ Error en /forgot-password:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// POST /verificar-codigo - Verificar código de recuperación
// =====================================================
app.post("/verificar-codigo", async (req, res) => {
  console.log("📥 Datos recibidos en /verificar-codigo:", JSON.stringify(req.body));

  try {
    const { correo, codigo } = req.body;

    if (!correo || !codigo) {
      console.log("❌ Validación fallida: campos faltantes");
      return res.status(400).json({ error: "Correo y código son requeridos" });
    }

    // Verificar código en la base de datos
    const checkQuery = `
      SELECT token_id, usu_email, token, fecha_expiracion, usado 
      FROM tokens_recuperacion 
      WHERE usu_email = ? AND token = ? AND usado = 0
    `;
    const [results] = await promisePool.query(checkQuery, [correo, codigo]);

    if (results.length === 0) {
      console.log("❌ Código inválido o ya usado para:", correo);
      return res.status(400).json({ 
        success: false,
        message: "Código inválido o expirado" 
      });
    }

    const tokenData = results[0];
    const fechaExpiracion = new Date(tokenData.fecha_expiracion);
    const ahora = new Date();

    if (ahora > fechaExpiracion) {
      console.log("❌ Código expirado para:", correo);
      return res.status(400).json({ 
        success: false,
        message: "Código expirado. Solicite uno nuevo" 
      });
    }

    // Marcar código como usado
    const updateQuery = "UPDATE tokens_recuperacion SET usado = 1 WHERE token_id = ?";
    await promisePool.query(updateQuery, [tokenData.token_id]);

    console.log("✅ Código verificado exitosamente para:", correo);

    res.json({
      success: true,
      message: "Código verificado exitosamente"
    });
  } catch (error) {
    console.error("❌ Error en /verificar-codigo:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// POST /change-password - Cambiar contraseña
// =====================================================
app.post("/change-password", async (req, res) => {
  console.log("📥 Datos recibidos en /change-password:", JSON.stringify(req.body));

  try {
    const { correo, nuevaContraseña, confirmarContraseña } = req.body;

    if (!correo || !nuevaContraseña || !confirmarContraseña) {
      console.log("❌ Validación fallida: campos faltantes");
      return res.status(400).json({ error: "Todos los campos son requeridos" });
    }

    if (nuevaContraseña !== confirmarContraseña) {
      console.log("❌ Validación fallida: contraseñas no coinciden");
      return res.status(400).json({ error: "Las contraseñas no coinciden" });
    }

    if (nuevaContraseña.length < 6) {
      console.log("❌ Validación fallida: contraseña muy corta");
      return res.status(400).json({ error: "La contraseña debe tener al menos 6 caracteres" });
    }

    // Verificar si el correo existe
    const checkQuery = "SELECT usu_id FROM usuarios WHERE usu_email = ? AND activo = 1";
    const [checkResults] = await promisePool.query(checkQuery, [correo]);

    if (checkResults.length === 0) {
      console.log("❌ Usuario no encontrado:", correo);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Verificar que existe un código verificado para este correo
    const verifyCodeQuery = `
      SELECT token_id FROM tokens_recuperacion 
      WHERE usu_email = ? AND usado = 1 
      ORDER BY fecha_creacion DESC LIMIT 1
    `;
    const [codeResults] = await promisePool.query(verifyCodeQuery, [correo]);

    if (codeResults.length === 0) {
      console.log("❌ No se encontró código verificado para:", correo);
      return res.status(400).json({ error: "Debe verificar el código primero" });
    }

    // Actualizar contraseña
    const updateQuery = "UPDATE usuarios SET usu_password = ? WHERE usu_email = ?";
    await promisePool.query(updateQuery, [nuevaContraseña, correo]);

    console.log("✅ Contraseña actualizada exitosamente para:", correo);
    res.json({
      message: "Contraseña actualizada exitosamente",
      success: true
    });
  } catch (error) {
    console.error("❌ Error en /change-password:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// POST /cuestionario - Enviar cuestionario
// =====================================================
app.post("/cuestionario", async (req, res) => {
  console.log("📥 Datos recibidos en /cuestionario:", JSON.stringify(req.body));

  try {
    const {
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10
    } = req.body;

    // Validar que usu_id esté presente
    if (!usu_id || usu_id <= 0) {
      console.log("❌ Validación fallida: usu_id inválido");
      return res.status(400).json({ error: "ID de usuario es requerido y debe ser válido" });
    }

    // Validar que todas las preguntas estén presentes y no estén vacías
    const preguntas = [pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
                      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10];
    
    for (let i = 0; i < preguntas.length; i++) {
      if (!preguntas[i] || preguntas[i].trim() === "") {
        console.log(`❌ Validación fallida: pregunta${i + 1} está vacía`);
        return res.status(400).json({ error: `La pregunta ${i + 1} es requerida` });
      }
    }

    // Verificar que el usuario existe
    const checkUserQuery = "SELECT usu_id FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [userResults] = await promisePool.query(checkUserQuery, [usu_id]);

    if (userResults.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Insertar cuestionario
    const query = `INSERT INTO cuestionarios (
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10,
      fecha_creacion
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`;

    const [result] = await promisePool.query(query, [
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10
    ]);

    console.log("✅ Cuestionario guardado exitosamente, ID:", result.insertId);

    res.json({
      message: "Cuestionario guardado exitosamente",
      success: true,
      cuestionario_id: result.insertId
    });
  } catch (error) {
    console.error("❌ Error en /cuestionario:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al guardar cuestionario: " + error.message });
  }
});

// =====================================================
// POST /test-conocimiento - Enviar Test de Conocimiento y Prácticas sobre Anemia
// =====================================================
app.post("/test-conocimiento", async (req, res) => {
  console.log("📥 Datos recibidos en /test-conocimiento:", JSON.stringify(req.body));

  try {
    const {
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10
    } = req.body;

    // Validar que usu_id esté presente
    if (!usu_id || usu_id <= 0) {
      console.log("❌ Validación fallida: usu_id inválido");
      return res.status(400).json({ error: "ID de usuario es requerido y debe ser válido" });
    }

    // Validar que todas las preguntas estén presentes y no estén vacías
    const preguntas = [pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
                      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10];
    
    for (let i = 0; i < preguntas.length; i++) {
      if (!preguntas[i] || preguntas[i].trim() === "") {
        console.log(`❌ Validación fallida: pregunta${i + 1} está vacía`);
        return res.status(400).json({ error: `La pregunta ${i + 1} es requerida` });
      }
    }

    // Verificar que el usuario existe
    const checkUserQuery = "SELECT usu_id FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [userResults] = await promisePool.query(checkUserQuery, [usu_id]);

    if (userResults.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Calcular score del test (reutilizando la variable preguntas ya declarada)
    const score = calcularScore(preguntas);

    // Insertar test de conocimiento con score
    const query = `INSERT INTO test_conocimiento (
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10,
      score,
      fecha_creacion
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`;

    const [result] = await promisePool.query(query, [
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10,
      score
    ]);

    console.log("✅ Test de conocimiento guardado exitosamente, ID:", result.insertId, "Score:", score);

    res.json({
      message: "Test de conocimiento guardado exitosamente",
      success: true,
      test_id: result.insertId
    });
  } catch (error) {
    console.error("❌ Error en /test-conocimiento:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al guardar test de conocimiento: " + error.message });
  }
});

// =====================================================
// POST /encuesta-satisfaccion - Enviar Encuesta de Satisfacción
// =====================================================
app.post("/encuesta-satisfaccion", async (req, res) => {
  console.log("📥 Datos recibidos en /encuesta-satisfaccion:", JSON.stringify(req.body));

  try {
    const {
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10
    } = req.body;

    // Validar que usu_id esté presente
    if (!usu_id || usu_id <= 0) {
      console.log("❌ Validación fallida: usu_id inválido");
      return res.status(400).json({ error: "ID de usuario es requerido y debe ser válido" });
    }

    // Validar que todas las preguntas estén presentes y no estén vacías
    const preguntas = [pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
                      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10];
    
    for (let i = 0; i < preguntas.length; i++) {
      if (!preguntas[i] || preguntas[i].trim() === "") {
        console.log(`❌ Validación fallida: pregunta${i + 1} está vacía`);
        return res.status(400).json({ error: `La pregunta ${i + 1} es requerida` });
      }
    }

    // Verificar que el usuario existe
    const checkUserQuery = "SELECT usu_id FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [userResults] = await promisePool.query(checkUserQuery, [usu_id]);

    if (userResults.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Calcular score de la encuesta (reutilizando la variable preguntas ya declarada)
    const score = calcularScore(preguntas);

    // Insertar encuesta de satisfacción con score
    const query = `INSERT INTO encuesta_satisfaccion (
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10,
      score,
      fecha_creacion
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())`;

    const [result] = await promisePool.query(query, [
      usu_id,
      pregunta1, pregunta2, pregunta3, pregunta4, pregunta5,
      pregunta6, pregunta7, pregunta8, pregunta9, pregunta10,
      score
    ]);

    console.log("✅ Encuesta de satisfacción guardada exitosamente, ID:", result.insertId, "Score:", score);

    res.json({
      message: "Encuesta de satisfacción guardada exitosamente",
      success: true,
      encuesta_id: result.insertId
    });
  } catch (error) {
    console.error("❌ Error en /encuesta-satisfaccion:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al guardar encuesta de satisfacción: " + error.message });
  }
});

// =====================================================
// GET /cuestionarios/:usu_id - Obtener cuestionarios de un usuario
// =====================================================
app.get("/cuestionarios/:usu_id", async (req, res) => {
  try {
    const usu_id = req.params.usu_id;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    const query = "SELECT * FROM cuestionarios WHERE usu_id = ? ORDER BY fecha_creacion DESC";
    const [results] = await promisePool.query(query, [usu_id]);

    console.log(`✅ Obtenidos ${results.length} cuestionarios para usuario ${usu_id}`);

    res.json({
      cuestionarios: results,
      total: results.length
    });
  } catch (error) {
    console.error("❌ Error en /cuestionarios/:usu_id:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// GET /resultados/:usu_id - Obtener resultados de encuestas con scores
// =====================================================
app.get("/resultados/:usu_id", async (req, res) => {
  console.log("📥 Solicitud de resultados para usuario:", req.params.usu_id);

  try {
    const usu_id = req.params.usu_id;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    // Verificar que el usuario existe
    const checkUserQuery = "SELECT usu_id FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [userResults] = await promisePool.query(checkUserQuery, [usu_id]);

    if (userResults.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Obtener el último test de conocimiento con score
    const testQuery = `
      SELECT test_id, score, fecha_creacion 
      FROM test_conocimiento 
      WHERE usu_id = ? 
      ORDER BY fecha_creacion DESC 
      LIMIT 1
    `;
    const [testResults] = await promisePool.query(testQuery, [usu_id]);

    // Obtener la última encuesta de satisfacción con score
    const encuestaQuery = `
      SELECT encuesta_id, score, fecha_creacion 
      FROM encuesta_satisfaccion 
      WHERE usu_id = ? 
      ORDER BY fecha_creacion DESC 
      LIMIT 1
    `;
    const [encuestaResults] = await promisePool.query(encuestaQuery, [usu_id]);

    // Obtener el último juego de alimentos con score
    const juegoAlimentosQuery = `
      SELECT juego_id, score, respuestas_correctas, total_preguntas, fecha_creacion 
      FROM juego_alimentos 
      WHERE usu_id = ? 
      ORDER BY fecha_creacion DESC 
      LIMIT 1
    `;
    const [juegoAlimentosResults] = await promisePool.query(juegoAlimentosQuery, [usu_id]);

    // Obtener el último juego de combinaciones con score
    const juegoCombinacionesQuery = `
      SELECT juego_id, score, combinaciones_correctas, total_combinaciones, tiempo_segundos, fecha_creacion 
      FROM juego_combinaciones 
      WHERE usu_id = ? 
      ORDER BY fecha_creacion DESC 
      LIMIT 1
    `;
    const [juegoCombinacionesResults] = await promisePool.query(juegoCombinacionesQuery, [usu_id]);

    const testConocimiento = testResults.length > 0 ? {
      test_id: testResults[0].test_id,
      score: testResults[0].score || 0,
      fecha_creacion: testResults[0].fecha_creacion,
      completado: true
    } : {
      score: 0,
      completado: false
    };

    const encuestaSatisfaccion = encuestaResults.length > 0 ? {
      encuesta_id: encuestaResults[0].encuesta_id,
      score: encuestaResults[0].score || 0,
      fecha_creacion: encuestaResults[0].fecha_creacion,
      completado: true
    } : {
      score: 0,
      completado: false
    };

    const juegoAlimentos = juegoAlimentosResults.length > 0 ? {
      juego_id: juegoAlimentosResults[0].juego_id,
      score: juegoAlimentosResults[0].score || 0,
      respuestas_correctas: juegoAlimentosResults[0].respuestas_correctas || 0,
      total_preguntas: juegoAlimentosResults[0].total_preguntas || 10,
      fecha_creacion: juegoAlimentosResults[0].fecha_creacion,
      completado: true
    } : {
      score: 0,
      respuestas_correctas: 0,
      total_preguntas: 10,
      completado: false
    };

    const juegoCombinaciones = juegoCombinacionesResults.length > 0 ? {
      juego_id: juegoCombinacionesResults[0].juego_id,
      score: juegoCombinacionesResults[0].score || 0,
      combinaciones_correctas: juegoCombinacionesResults[0].combinaciones_correctas || 0,
      total_combinaciones: juegoCombinacionesResults[0].total_combinaciones || 8,
      tiempo_segundos: juegoCombinacionesResults[0].tiempo_segundos || 0,
      fecha_creacion: juegoCombinacionesResults[0].fecha_creacion,
      completado: true
    } : {
      score: 0,
      combinaciones_correctas: 0,
      total_combinaciones: 8,
      tiempo_segundos: 0,
      completado: false
    };

    console.log("✅ Resultados obtenidos:", {
      testConocimiento: testConocimiento.score,
      encuestaSatisfaccion: encuestaSatisfaccion.score,
      juegoAlimentos: juegoAlimentos.score,
      juegoCombinaciones: juegoCombinaciones.score
    });

    res.json({
      success: true,
      usu_id: parseInt(usu_id),
      test_conocimiento: testConocimiento,
      encuesta_satisfaccion: encuestaSatisfaccion,
      juego_alimentos: juegoAlimentos,
      juego_combinaciones: juegoCombinaciones
    });
  } catch (error) {
    console.error("❌ Error en /resultados/:usu_id:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// GET /perfil/:usu_id - Obtener datos del perfil del usuario
// =====================================================
app.get("/perfil/:usu_id", async (req, res) => {
  console.log("📥 Solicitud de perfil para usuario:", req.params.usu_id);

  try {
    const usu_id = req.params.usu_id;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    // Obtener datos del usuario incluyendo fecha de nacimiento
    const query = "SELECT usu_id, usu_nombres, usu_apellidos, usu_email, fecha_nacimiento FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [results] = await promisePool.query(query, [usu_id]);

    if (results.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    const user = results[0];
    console.log("✅ Perfil obtenido para usuario:", usu_id);

    res.json({
      success: true,
      user: {
        id: user.usu_id,
        nombres: user.usu_nombres,
        apellidos: user.usu_apellidos,
        correo: user.usu_email,
        fechaNacimiento: user.fecha_nacimiento ? user.fecha_nacimiento.toISOString().split('T')[0] : null
      }
    });
  } catch (error) {
    console.error("❌ Error en /perfil/:usu_id:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// PUT /perfil/:usu_id - Actualizar datos del perfil del usuario
// =====================================================
app.put("/perfil/:usu_id", async (req, res) => {
  console.log("📥 Actualización de perfil para usuario:", req.params.usu_id);
  console.log("📥 Datos recibidos:", JSON.stringify(req.body));

  try {
    const usu_id = req.params.usu_id;
    const { nombres, apellidos, correo } = req.body;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    // Validar campos requeridos
    if (!nombres || !apellidos || !correo) {
      console.log("❌ Validación fallida: campos faltantes");
      return res.status(400).json({ error: "Nombres, apellidos y correo son requeridos" });
    }

    // Validar formato de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(correo)) {
      console.log("❌ Validación fallida: formato de email inválido");
      return res.status(400).json({ error: "Formato de correo inválido" });
    }

    // Verificar que el usuario existe
    const checkUserQuery = "SELECT usu_id, usu_email FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [userResults] = await promisePool.query(checkUserQuery, [usu_id]);

    if (userResults.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Verificar si el correo ya está en uso por otro usuario
    const checkEmailQuery = "SELECT usu_id FROM usuarios WHERE usu_email = ? AND usu_id != ?";
    const [emailResults] = await promisePool.query(checkEmailQuery, [correo, usu_id]);

    if (emailResults.length > 0) {
      console.log("❌ Correo ya está en uso por otro usuario");
      return res.status(400).json({ error: "El correo electrónico ya está en uso" });
    }

    // Actualizar datos del usuario
    const updateQuery = "UPDATE usuarios SET usu_nombres = ?, usu_apellidos = ?, usu_email = ? WHERE usu_id = ?";
    await promisePool.query(updateQuery, [nombres, apellidos, correo, usu_id]);

    console.log("✅ Perfil actualizado exitosamente para usuario:", usu_id);

    res.json({
      success: true,
      message: "Perfil actualizado exitosamente",
      user: {
        id: parseInt(usu_id),
        nombres: nombres,
        apellidos: apellidos,
        correo: correo
      }
    });
  } catch (error) {
    console.error("❌ Error en /perfil/:usu_id (PUT):", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al actualizar perfil: " + error.message });
  }
});

// =====================================================
// POST /juego-alimentos - Guardar resultado del juego "¿Qué alimento es?"
// =====================================================
app.post("/juego-alimentos", async (req, res) => {
  console.log("📥 Guardar resultado de juego alimentos");
  console.log("📥 Datos recibidos:", JSON.stringify(req.body));

  try {
    const { usu_id, respuestas_correctas, total_preguntas } = req.body;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    if (respuestas_correctas === undefined || total_preguntas === undefined) {
      return res.status(400).json({ error: "respuestas_correctas y total_preguntas son requeridos" });
    }

    // Verificar que el usuario existe
    const checkUserQuery = "SELECT usu_id FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [userResults] = await promisePool.query(checkUserQuery, [usu_id]);

    if (userResults.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Calcular score: respuestas correctas * 10
    const score = respuestas_correctas * 10;

    // Insertar resultado del juego
    const insertQuery = `
      INSERT INTO juego_alimentos (usu_id, respuestas_correctas, total_preguntas, score)
      VALUES (?, ?, ?, ?)
    `;
    const [insertResult] = await promisePool.query(insertQuery, [
      usu_id,
      respuestas_correctas,
      total_preguntas || 10,
      score
    ]);

    console.log("✅ Resultado de juego alimentos guardado:", {
      juego_id: insertResult.insertId,
      score: score
    });

    res.json({
      success: true,
      message: "Resultado del juego guardado exitosamente",
      juego_id: insertResult.insertId,
      score: score,
      respuestas_correctas: respuestas_correctas,
      total_preguntas: total_preguntas || 10
    });
  } catch (error) {
    console.error("❌ Error en /juego-alimentos:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al guardar resultado del juego: " + error.message });
  }
});

// =====================================================
// POST /juego-combinaciones - Guardar resultado del juego "Combina y Gana"
// =====================================================
app.post("/juego-combinaciones", async (req, res) => {
  console.log("📥 Guardar resultado de juego combinaciones");
  console.log("📥 Datos recibidos:", JSON.stringify(req.body));

  try {
    const { usu_id, combinaciones_correctas, total_combinaciones, tiempo_segundos } = req.body;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    if (combinaciones_correctas === undefined || total_combinaciones === undefined) {
      return res.status(400).json({ error: "combinaciones_correctas y total_combinaciones son requeridos" });
    }

    // Verificar que el usuario existe
    const checkUserQuery = "SELECT usu_id FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [userResults] = await promisePool.query(checkUserQuery, [usu_id]);

    if (userResults.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Calcular score: combinaciones correctas * 15 - (tiempo_segundos / 10)
    // Máximo score si todas correctas: 8 * 15 = 120 puntos
    // Bonus por velocidad: menos tiempo = más puntos
    const tiempoBonus = tiempo_segundos > 0 ? Math.max(0, 30 - Math.floor(tiempo_segundos / 10)) : 0;
    const score = (combinaciones_correctas * 15) + tiempoBonus;

    // Insertar resultado del juego
    const insertQuery = `
      INSERT INTO juego_combinaciones (usu_id, combinaciones_correctas, total_combinaciones, tiempo_segundos, score)
      VALUES (?, ?, ?, ?, ?)
    `;
    const [insertResult] = await promisePool.query(insertQuery, [
      usu_id,
      combinaciones_correctas,
      total_combinaciones || 8,
      tiempo_segundos || 0,
      score
    ]);

    console.log("✅ Resultado de juego combinaciones guardado:", {
      juego_id: insertResult.insertId,
      score: score
    });

    res.json({
      success: true,
      message: "Resultado del juego guardado exitosamente",
      juego_id: insertResult.insertId,
      score: score,
      combinaciones_correctas: combinaciones_correctas,
      total_combinaciones: total_combinaciones || 8,
      tiempo_segundos: tiempo_segundos || 0
    });
  } catch (error) {
    console.error("❌ Error en /juego-combinaciones:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al guardar resultado del juego: " + error.message });
  }
});

// =====================================================
// GET /usuarios - Obtener lista de todos los usuarios (solo para administradores)
// =====================================================
app.get("/usuarios", async (req, res) => {
  console.log("📥 Solicitud de lista de usuarios");

  try {
    // Obtener todos los usuarios activos con cálculo de edad
    const query = `
      SELECT 
        usu_id,
        usu_nombres,
        usu_apellidos,
        usu_email,
        fecha_nacimiento,
        tipo_usuario,
        fecha_registro,
        activo,
        CASE 
          WHEN fecha_nacimiento IS NOT NULL THEN
            TIMESTAMPDIFF(YEAR, fecha_nacimiento, CURDATE())
          ELSE NULL
        END AS edad
      FROM usuarios 
      WHERE activo = 1
      ORDER BY fecha_registro DESC
    `;
    const [results] = await promisePool.query(query);

    console.log(`✅ Obtenidos ${results.length} usuarios`);

    // Formatear respuesta
    const usuarios = results.map(user => ({
      id: user.usu_id,
      nombres: user.usu_nombres,
      apellidos: user.usu_apellidos,
      correo: user.usu_email,
      fechaNacimiento: user.fecha_nacimiento ? user.fecha_nacimiento.toISOString().split('T')[0] : null,
      edad: user.edad,
      tipoUsuario: user.tipo_usuario,
      fechaRegistro: user.fecha_registro,
      activo: user.activo === 1
    }));

    res.json({
      success: true,
      total: usuarios.length,
      usuarios: usuarios
    });
  } catch (error) {
    console.error("❌ Error en /usuarios:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// GET /usuario/:usu_id/detalle - Obtener datos completos de un usuario (para administrador)
// =====================================================
app.get("/usuario/:usu_id/detalle", async (req, res) => {
  console.log("📥 Solicitud de detalle de usuario:", req.params.usu_id);

  try {
    const usu_id = req.params.usu_id;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    // Obtener datos completos del usuario
    const queryUsuario = `
      SELECT 
        usu_id,
        usu_nombres,
        usu_apellidos,
        usu_email,
        fecha_nacimiento,
        tipo_usuario,
        fecha_registro,
        activo,
        CASE 
          WHEN fecha_nacimiento IS NOT NULL THEN
            TIMESTAMPDIFF(YEAR, fecha_nacimiento, CURDATE())
          ELSE NULL
        END AS edad
      FROM usuarios 
      WHERE usu_id = ? AND activo = 1
    `;
    const [userResults] = await promisePool.query(queryUsuario, [usu_id]);

    if (userResults.length === 0) {
      console.log("❌ Usuario no encontrado:", usu_id);
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    const user = userResults[0];

    // Obtener estadísticas del usuario
    const queryStats = `
      SELECT 
        (SELECT COUNT(*) FROM cuestionarios WHERE usu_id = ?) as total_cuestionarios,
        (SELECT COUNT(*) FROM test_conocimiento WHERE usu_id = ?) as total_tests,
        (SELECT COUNT(*) FROM encuesta_satisfaccion WHERE usu_id = ?) as total_encuestas,
        (SELECT COUNT(*) FROM juego_alimentos WHERE usu_id = ?) as total_juegos_alimentos,
        (SELECT COUNT(*) FROM juego_combinaciones WHERE usu_id = ?) as total_juegos_combinaciones,
        (SELECT AVG(score) FROM test_conocimiento WHERE usu_id = ?) as promedio_test,
        (SELECT AVG(score) FROM encuesta_satisfaccion WHERE usu_id = ?) as promedio_encuesta,
        (SELECT AVG(score) FROM juego_alimentos WHERE usu_id = ?) as promedio_juego_alimentos,
        (SELECT AVG(score) FROM juego_combinaciones WHERE usu_id = ?) as promedio_juego_combinaciones
    `;
    const [statsResults] = await promisePool.query(queryStats, [
      usu_id, usu_id, usu_id, usu_id, usu_id, usu_id, usu_id, usu_id, usu_id
    ]);

    const stats = statsResults[0];

    console.log("✅ Detalle de usuario obtenido:", usu_id);

    res.json({
      success: true,
      usuario: {
        id: user.usu_id,
        nombres: user.usu_nombres,
        apellidos: user.usu_apellidos,
        correo: user.usu_email,
        fechaNacimiento: user.fecha_nacimiento ? user.fecha_nacimiento.toISOString().split('T')[0] : null,
        edad: user.edad,
        tipoUsuario: user.tipo_usuario,
        fechaRegistro: user.fecha_registro,
        activo: user.activo === 1
      },
      estadisticas: {
        totalCuestionarios: stats.total_cuestionarios || 0,
        totalTests: stats.total_tests || 0,
        totalEncuestas: stats.total_encuestas || 0,
        totalJuegosAlimentos: stats.total_juegos_alimentos || 0,
        totalJuegosCombinaciones: stats.total_juegos_combinaciones || 0,
        promedioTest: stats.promedio_test ? parseFloat(stats.promedio_test).toFixed(2) : "0.00",
        promedioEncuesta: stats.promedio_encuesta ? parseFloat(stats.promedio_encuesta).toFixed(2) : "0.00",
        promedioJuegoAlimentos: stats.promedio_juego_alimentos ? parseFloat(stats.promedio_juego_alimentos).toFixed(2) : "0.00",
        promedioJuegoCombinaciones: stats.promedio_juego_combinaciones ? parseFloat(stats.promedio_juego_combinaciones).toFixed(2) : "0.00"
      }
    });
  } catch (error) {
    console.error("❌ Error en /usuario/:usu_id/detalle:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// GET /usuario/:usu_id/analisis - Obtener datos de análisis con promedios y estadísticas detalladas
// =====================================================
app.get("/usuario/:usu_id/analisis", async (req, res) => {
  console.log("📥 Solicitud de análisis de usuario:", req.params.usu_id);

  try {
    const usu_id = req.params.usu_id;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    // Verificar que el usuario existe
    const checkUserQuery = "SELECT usu_id FROM usuarios WHERE usu_id = ? AND activo = 1";
    const [userResults] = await promisePool.query(checkUserQuery, [usu_id]);

    if (userResults.length === 0) {
      return res.status(404).json({ error: "Usuario no encontrado" });
    }

    // Tabla 1: Test de Conocimiento - Historial completo con fechas
    const queryTests = `
      SELECT 
        test_id,
        score,
        fecha_creacion,
        DATE_FORMAT(fecha_creacion, '%d/%m/%Y') as fecha_formateada
      FROM test_conocimiento 
      WHERE usu_id = ? 
      ORDER BY fecha_creacion DESC
    `;
    const [testsResults] = await promisePool.query(queryTests, [usu_id]);

    // Tabla 2: Encuestas de Satisfacción - Historial completo con fechas
    const queryEncuestas = `
      SELECT 
        encuesta_id,
        score,
        fecha_creacion,
        DATE_FORMAT(fecha_creacion, '%d/%m/%Y') as fecha_formateada
      FROM encuesta_satisfaccion 
      WHERE usu_id = ? 
      ORDER BY fecha_creacion DESC
    `;
    const [encuestasResults] = await promisePool.query(queryEncuestas, [usu_id]);

    // Tabla 3: Juegos - Historial completo con detalles
    const queryJuegos = `
      SELECT 
        'alimentos' as tipo_juego,
        juego_id,
        respuestas_correctas,
        total_preguntas,
        score,
        fecha_creacion,
        DATE_FORMAT(fecha_creacion, '%d/%m/%Y') as fecha_formateada
      FROM juego_alimentos 
      WHERE usu_id = ?
      
      UNION ALL
      
      SELECT 
        'combinaciones' as tipo_juego,
        juego_id,
        combinaciones_correctas as respuestas_correctas,
        total_combinaciones as total_preguntas,
        score,
        fecha_creacion,
        DATE_FORMAT(fecha_creacion, '%d/%m/%Y') as fecha_formateada
      FROM juego_combinaciones 
      WHERE usu_id = ?
      
      ORDER BY fecha_creacion DESC
    `;
    const [juegosResults] = await promisePool.query(queryJuegos, [usu_id, usu_id]);

    // Calcular promedios y estadísticas generales
    const queryPromedios = `
      SELECT 
        (SELECT AVG(score) FROM test_conocimiento WHERE usu_id = ?) as promedio_test,
        (SELECT MAX(score) FROM test_conocimiento WHERE usu_id = ?) as maximo_test,
        (SELECT MIN(score) FROM test_conocimiento WHERE usu_id = ?) as minimo_test,
        (SELECT AVG(score) FROM encuesta_satisfaccion WHERE usu_id = ?) as promedio_encuesta,
        (SELECT MAX(score) FROM encuesta_satisfaccion WHERE usu_id = ?) as maximo_encuesta,
        (SELECT MIN(score) FROM encuesta_satisfaccion WHERE usu_id = ?) as minimo_encuesta,
        (SELECT AVG(score) FROM juego_alimentos WHERE usu_id = ?) as promedio_juego_alimentos,
        (SELECT AVG(score) FROM juego_combinaciones WHERE usu_id = ?) as promedio_juego_combinaciones
    `;
    const [promediosResults] = await promisePool.query(queryPromedios, [
      usu_id, usu_id, usu_id, usu_id, usu_id, usu_id, usu_id, usu_id
    ]);

    const promedios = promediosResults[0];

    // Preparar datos para gráficos
    const datosGrafico = {
      tests: testsResults.map(t => ({
        fecha: t.fecha_formateada,
        score: t.score || 0
      })),
      encuestas: encuestasResults.map(e => ({
        fecha: e.fecha_formateada,
        score: e.score || 0
      })),
      juegos: juegosResults.map(j => ({
        fecha: j.fecha_formateada,
        score: j.score || 0,
        tipo: j.tipo_juego
      }))
    };

    console.log("✅ Análisis de usuario obtenido:", usu_id);

    res.json({
      success: true,
      tablas: {
        testConocimiento: testsResults.map(t => ({
          id: t.test_id,
          score: t.score || 0,
          fecha: t.fecha_formateada,
          fechaCompleta: t.fecha_creacion
        })),
        encuestaSatisfaccion: encuestasResults.map(e => ({
          id: e.encuesta_id,
          score: e.score || 0,
          fecha: e.fecha_formateada,
          fechaCompleta: e.fecha_creacion
        })),
        juegos: juegosResults.map(j => ({
          id: j.juego_id,
          tipo: j.tipo_juego,
          respuestasCorrectas: j.respuestas_correctas || 0,
          totalPreguntas: j.total_preguntas || 0,
          score: j.score || 0,
          fecha: j.fecha_formateada,
          fechaCompleta: j.fecha_creacion
        }))
      },
      promedios: {
        testConocimiento: {
          promedio: promedios.promedio_test ? parseFloat(promedios.promedio_test).toFixed(2) : "0.00",
          maximo: promedios.maximo_test || 0,
          minimo: promedios.minimo_test || 0,
          total: testsResults.length
        },
        encuestaSatisfaccion: {
          promedio: promedios.promedio_encuesta ? parseFloat(promedios.promedio_encuesta).toFixed(2) : "0.00",
          maximo: promedios.maximo_encuesta || 0,
          minimo: promedios.minimo_encuesta || 0,
          total: encuestasResults.length
        },
        juegos: {
          promedioAlimentos: promedios.promedio_juego_alimentos ? parseFloat(promedios.promedio_juego_alimentos).toFixed(2) : "0.00",
          promedioCombinaciones: promedios.promedio_juego_combinaciones ? parseFloat(promedios.promedio_juego_combinaciones).toFixed(2) : "0.00",
          total: juegosResults.length
        }
      },
      datosGrafico: datosGrafico
    });
  } catch (error) {
    console.error("❌ Error en /usuario/:usu_id/analisis:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error en el servidor: " + error.message });
  }
});

// =====================================================
// GET /notificaciones/:usu_id - Obtener notificaciones de un usuario
// =====================================================
app.get("/notificaciones/:usu_id", async (req, res) => {
  console.log("📥 Solicitud de notificaciones para usuario:", req.params.usu_id);

  try {
    const usu_id = req.params.usu_id;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ error: "ID de usuario inválido" });
    }

    const query = `
      SELECT 
        notificacion_id,
        usu_id,
        titulo,
        mensaje,
        tipo,
        leida,
        fecha_creacion,
        fecha_leida,
        DATE_FORMAT(fecha_creacion, '%d/%m/%Y %H:%i') as fecha_formateada
      FROM notificaciones 
      WHERE usu_id = ? 
      ORDER BY fecha_creacion DESC
    `;
    const [results] = await promisePool.query(query, [usu_id]);

    // Contar no leídas
    const queryNoLeidas = "SELECT COUNT(*) as total FROM notificaciones WHERE usu_id = ? AND leida = 0";
    const [noLeidasResult] = await promisePool.query(queryNoLeidas, [usu_id]);
    const totalNoLeidas = parseInt(noLeidasResult[0].total) || 0;

    console.log("✅ Notificaciones obtenidas:", results.length, "Total no leídas:", totalNoLeidas);
    console.log("📋 Detalle de notificaciones:", JSON.stringify(results, null, 2));

    // Si no hay notificaciones, devolver array vacío pero con success = true
    const notificaciones = results.length > 0 
      ? results.map(n => ({
          id: n.notificacion_id,
          usuId: n.usu_id,
          titulo: n.titulo,
          mensaje: n.mensaje,
          tipo: n.tipo,
          leida: n.leida === 1,
          fechaCreacion: n.fecha_creacion,
          fechaLeida: n.fecha_leida,
          fechaFormateada: n.fecha_formateada
        }))
      : [];

    res.json({
      success: true,
      notificaciones: notificaciones,
      totalNoLeidas: totalNoLeidas
    });
  } catch (error) {
    console.error("❌ Error en /notificaciones/:usu_id:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al obtener notificaciones: " + error.message });
  }
});

// =====================================================
// PUT /notificaciones/:notificacion_id/leer - Marcar notificación como leída
// =====================================================
app.put("/notificaciones/:notificacion_id/leer", async (req, res) => {
  console.log("📥 Marcar notificación como leída:", req.params.notificacion_id);

  try {
    const notificacion_id = req.params.notificacion_id;

    if (!notificacion_id || isNaN(notificacion_id)) {
      return res.status(400).json({ error: "ID de notificación inválido" });
    }

    const query = `
      UPDATE notificaciones 
      SET leida = 1, fecha_leida = NOW() 
      WHERE notificacion_id = ?
    `;
    const [result] = await promisePool.query(query, [notificacion_id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Notificación no encontrada" });
    }

    console.log("✅ Notificación marcada como leída:", notificacion_id);

    res.json({
      success: true,
      message: "Notificación marcada como leída"
    });
  } catch (error) {
    console.error("❌ Error en /notificaciones/:notificacion_id/leer:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al marcar notificación como leída: " + error.message });
  }
});

// =====================================================
// DELETE /notificaciones/:notificacion_id - Eliminar notificación
// =====================================================
app.delete("/notificaciones/:notificacion_id", async (req, res) => {
  console.log("📥 Eliminar notificación:", req.params.notificacion_id);

  try {
    const notificacion_id = req.params.notificacion_id;

    if (!notificacion_id || isNaN(notificacion_id)) {
      return res.status(400).json({ error: "ID de notificación inválido" });
    }

    const query = "DELETE FROM notificaciones WHERE notificacion_id = ?";
    const [result] = await promisePool.query(query, [notificacion_id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ error: "Notificación no encontrada" });
    }

    console.log("✅ Notificación eliminada:", notificacion_id);

    res.json({
      success: true,
      message: "Notificación eliminada correctamente"
    });
  } catch (error) {
    console.error("❌ Error en DELETE /notificaciones/:notificacion_id:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al eliminar notificación: " + error.message });
  }
});

// =====================================================
// POST /notificaciones - Crear notificación (para administradores o sistema)
// =====================================================
app.post("/notificaciones", async (req, res) => {
  console.log("📥 Crear notificación");

  try {
    const { usu_id, titulo, mensaje, tipo } = req.body;

    if (!usu_id || !titulo || !mensaje) {
      return res.status(400).json({ error: "Faltan campos requeridos: usu_id, titulo, mensaje" });
    }

    const tipoNotificacion = tipo || 'info';
    const tiposValidos = ['info', 'success', 'warning', 'error', 'system'];
    
    if (!tiposValidos.includes(tipoNotificacion)) {
      return res.status(400).json({ error: "Tipo de notificación inválido. Debe ser: " + tiposValidos.join(', ') });
    }

    const query = `
      INSERT INTO notificaciones (usu_id, titulo, mensaje, tipo) 
      VALUES (?, ?, ?, ?)
    `;
    const [result] = await promisePool.query(query, [usu_id, titulo, mensaje, tipoNotificacion]);

    console.log("✅ Notificación creada:", result.insertId);

    res.json({
      success: true,
      message: "Notificación creada correctamente",
      notificacion_id: result.insertId
    });
  } catch (error) {
    console.error("❌ Error en POST /notificaciones:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ error: "Error al crear notificación: " + error.message });
  }
});

// =====================================================
// ENDPOINTS DE MENSAJES DE SOPORTE
// =====================================================

// GET /soporte/mensajes/:usu_id - Obtener mensajes de un usuario
app.get("/soporte/mensajes/:usu_id", async (req, res) => {
  console.log("📥 Obtener mensajes de soporte para usuario:", req.params.usu_id);

  try {
    const { usu_id } = req.params;

    const query = `
      SELECT 
        m.mensaje_id,
        m.usu_id,
        m.admin_id,
        m.mensaje_padre_id,
        m.tipo_mensaje,
        m.asunto,
        m.mensaje,
        m.leido,
        m.fecha_creacion,
        m.fecha_leido,
        u.usu_nombres,
        u.usu_apellidos,
        u.usu_email,
        a.usu_nombres as admin_nombres,
        a.usu_apellidos as admin_apellidos
      FROM mensajes_soporte m
      LEFT JOIN usuarios u ON m.usu_id = u.usu_id
      LEFT JOIN usuarios a ON m.admin_id = a.usu_id
      WHERE m.usu_id = ?
      ORDER BY m.fecha_creacion ASC
    `;

    const [mensajes] = await promisePool.query(query, [usu_id]);

    console.log("✅ Mensajes obtenidos:", mensajes.length);

    res.json({
      success: true,
      mensajes: mensajes
    });
  } catch (error) {
    console.error("❌ Error en GET /soporte/mensajes/:usu_id:", error.message);
    res.status(500).json({ error: "Error al obtener mensajes: " + error.message });
  }
});

// GET /soporte/mensajes-admin - Obtener todos los mensajes para administradores
app.get("/soporte/mensajes-admin", async (req, res) => {
  console.log("📥 Obtener todos los mensajes de soporte (admin)");

  try {
    const query = `
      SELECT 
        m.mensaje_id,
        m.usu_id,
        m.admin_id,
        m.mensaje_padre_id,
        m.tipo_mensaje,
        m.asunto,
        m.mensaje,
        m.leido,
        m.fecha_creacion,
        m.fecha_leido,
        u.usu_nombres,
        u.usu_apellidos,
        u.usu_email,
        a.usu_nombres as admin_nombres,
        a.usu_apellidos as admin_apellidos
      FROM mensajes_soporte m
      LEFT JOIN usuarios u ON m.usu_id = u.usu_id
      LEFT JOIN usuarios a ON m.admin_id = a.usu_id
      ORDER BY m.fecha_creacion DESC
    `;

    const [mensajes] = await promisePool.query(query);

    console.log("✅ Mensajes obtenidos:", mensajes.length);

    res.json({
      success: true,
      mensajes: mensajes.map(m => ({
        mensajeId: m.mensaje_id,
        usuId: m.usu_id,
        adminId: m.admin_id,
        mensajePadreId: m.mensaje_padre_id,
        tipoMensaje: m.tipo_mensaje,
        asunto: m.asunto,
        mensaje: m.mensaje,
        leido: m.leido === 1,
        fechaCreacion: m.fecha_creacion,
        fechaLeido: m.fecha_leido,
        usuNombres: m.usu_nombres,
        usuApellidos: m.usu_apellidos,
        usuEmail: m.usu_email,
        adminNombres: m.admin_nombres,
        adminApellidos: m.admin_apellidos
      }))
    });
  } catch (error) {
    console.error("❌ Error en GET /soporte/mensajes-admin:", error.message);
    res.status(500).json({ error: "Error al obtener mensajes: " + error.message });
  }
});

// POST /soporte/mensaje - Crear nuevo mensaje de soporte
app.post("/soporte/mensaje", async (req, res) => {
  console.log("📥 Crear mensaje de soporte");

  try {
    const { usu_id, tipo_mensaje, asunto, mensaje, mensaje_padre_id } = req.body;

    if (!usu_id || !mensaje) {
      return res.status(400).json({ error: "Faltan campos requeridos: usu_id, mensaje" });
    }

    const tipo = tipo_mensaje || 'consulta';
    const tiposValidos = ['consulta', 'experiencia', 'respuesta'];
    
    if (!tiposValidos.includes(tipo)) {
      return res.status(400).json({ error: "Tipo de mensaje inválido. Debe ser: " + tiposValidos.join(', ') });
    }

    const query = `
      INSERT INTO mensajes_soporte (usu_id, tipo_mensaje, asunto, mensaje, mensaje_padre_id) 
      VALUES (?, ?, ?, ?, ?)
    `;
    const [result] = await promisePool.query(query, [usu_id, tipo, asunto || null, mensaje, mensaje_padre_id || null]);

    console.log("✅ Mensaje creado:", result.insertId);

    // Crear notificación para el usuario confirmando el envío
    let tituloNotificacion = "";
    let mensajeNotificacion = "";
    
    if (tipo === 'consulta') {
      tituloNotificacion = "Consulta enviada";
      mensajeNotificacion = `Tu consulta "${asunto || 'sin asunto'}" ha sido enviada correctamente. Te responderemos pronto.`;
    } else if (tipo === 'experiencia') {
      tituloNotificacion = "Experiencia compartida";
      mensajeNotificacion = "Gracias por compartir tu experiencia. Tu mensaje ha sido recibido y será revisado por nuestro equipo.";
    }

    if (tituloNotificacion) {
      try {
        await promisePool.query(
          "INSERT INTO notificaciones (usu_id, titulo, mensaje, tipo) VALUES (?, ?, ?, 'success')",
          [usu_id, tituloNotificacion, mensajeNotificacion]
        );
        console.log("✅ Notificación creada para usuario");
      } catch (notifError) {
        console.error("⚠️ Error al crear notificación:", notifError.message);
      }
    }

    // Crear notificación para el administrador sobre el nuevo mensaje
    try {
      const [admins] = await promisePool.query(
        "SELECT usu_id FROM usuarios WHERE tipo_usuario = 'admin' LIMIT 1"
      );
      
      if (admins.length > 0) {
        const adminId = admins[0].usu_id;
        let tituloAdmin = "";
        let mensajeAdmin = "";
        
        if (tipo === 'consulta') {
          tituloAdmin = "Nueva consulta de soporte";
          mensajeAdmin = `Has recibido una nueva consulta: "${asunto || 'sin asunto'}". Revisa el panel de administración para responder.`;
        } else if (tipo === 'experiencia') {
          tituloAdmin = "Nueva experiencia compartida";
          mensajeAdmin = "Un usuario ha compartido su experiencia con la aplicación. Revisa el panel de administración.";
        }
        
        if (tituloAdmin) {
          await promisePool.query(
            "INSERT INTO notificaciones (usu_id, titulo, mensaje, tipo) VALUES (?, ?, ?, 'info')",
            [adminId, tituloAdmin, mensajeAdmin]
          );
          console.log("✅ Notificación creada para administrador");
        }
      }
    } catch (adminNotifError) {
      console.error("⚠️ Error al crear notificación para admin:", adminNotifError.message);
    }

    res.json({
      success: true,
      message: "Mensaje enviado correctamente",
      mensaje_id: result.insertId
    });
  } catch (error) {
    console.error("❌ Error en POST /soporte/mensaje:", error.message);
    res.status(500).json({ error: "Error al enviar mensaje: " + error.message });
  }
});

// POST /soporte/respuesta - Responder mensaje (solo administradores)
app.post("/soporte/respuesta", async (req, res) => {
  console.log("📥 Responder mensaje de soporte");

  try {
    const { admin_id, mensaje_padre_id, mensaje } = req.body;

    if (!admin_id || !mensaje_padre_id || !mensaje) {
      return res.status(400).json({ error: "Faltan campos requeridos: admin_id, mensaje_padre_id, mensaje" });
    }

    // Obtener el usu_id del mensaje padre
    const [mensajePadre] = await promisePool.query(
      "SELECT usu_id FROM mensajes_soporte WHERE mensaje_id = ?",
      [mensaje_padre_id]
    );

    if (mensajePadre.length === 0) {
      return res.status(404).json({ error: "Mensaje padre no encontrado" });
    }

    const usu_id = mensajePadre[0].usu_id;

    const query = `
      INSERT INTO mensajes_soporte (usu_id, admin_id, mensaje_padre_id, tipo_mensaje, mensaje) 
      VALUES (?, ?, ?, 'respuesta', ?)
    `;
    const [result] = await promisePool.query(query, [usu_id, admin_id, mensaje_padre_id, mensaje]);

    // Marcar el mensaje padre como leído
    await promisePool.query(
      "UPDATE mensajes_soporte SET leido = 1, fecha_leido = NOW() WHERE mensaje_id = ?",
      [mensaje_padre_id]
    );

    // Crear notificación para el usuario sobre la respuesta del administrador
    try {
      await promisePool.query(
        "INSERT INTO notificaciones (usu_id, titulo, mensaje, tipo) VALUES (?, ?, ?, 'success')",
        [usu_id, "Respuesta recibida", "El administrador ha respondido a tu mensaje. Revisa la sección de Ayuda para ver la respuesta.", 'success']
      );
      console.log("✅ Notificación de respuesta creada para usuario");
    } catch (notifError) {
      console.error("⚠️ Error al crear notificación de respuesta:", notifError.message);
    }

    console.log("✅ Respuesta creada:", result.insertId);

    res.json({
      success: true,
      message: "Respuesta enviada correctamente",
      mensaje_id: result.insertId
    });
  } catch (error) {
    console.error("❌ Error en POST /soporte/respuesta:", error.message);
    res.status(500).json({ error: "Error al enviar respuesta: " + error.message });
  }
});

// PUT /soporte/mensaje/:mensaje_id/leer - Marcar mensaje como leído
app.put("/soporte/mensaje/:mensaje_id/leer", async (req, res) => {
  console.log("📥 Marcar mensaje como leído:", req.params.mensaje_id);

  try {
    const { mensaje_id } = req.params;

    const query = `
      UPDATE mensajes_soporte 
      SET leido = 1, fecha_leido = NOW() 
      WHERE mensaje_id = ?
    `;
    await promisePool.query(query, [mensaje_id]);

    console.log("✅ Mensaje marcado como leído");

    res.json({
      success: true,
      message: "Mensaje marcado como leído"
    });
  } catch (error) {
    console.error("❌ Error en PUT /soporte/mensaje/:mensaje_id/leer:", error.message);
    res.status(500).json({ error: "Error al marcar mensaje como leído: " + error.message });
  }
});

// GET /soporte/central-telefonica - Obtener información de central telefónica
app.get("/soporte/central-telefonica", async (req, res) => {
  console.log("📥 Obtener central telefónica");

  try {
    const query = `
      SELECT central_id, nombre, telefono, horario_atencion 
      FROM central_telefonica 
      WHERE activo = 1 
      ORDER BY orden ASC
    `;

    const [centrales] = await promisePool.query(query);

    console.log("✅ Centrales obtenidas:", centrales.length);

    res.json({
      success: true,
      centrales: centrales
    });
  } catch (error) {
    console.error("❌ Error en GET /soporte/central-telefonica:", error.message);
    res.status(500).json({ error: "Error al obtener central telefónica: " + error.message });
  }
});

// =====================================================
// CRUD DE USUARIOS PARA ADMINISTRADORES
// =====================================================

// PUT /usuario/:usu_id - Actualizar usuario (solo administradores)
app.put("/usuario/:usu_id", async (req, res) => {
  console.log("📝 Actualizar usuario:", req.params.usu_id);

  try {
    const usu_id = req.params.usu_id;
    const { nombres, apellidos, email, fechaNacimiento, activo } = req.body;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ success: false, error: "ID de usuario inválido" });
    }

    // Validar que el usuario no sea administrador (protección)
    const [checkUser] = await promisePool.query(
      "SELECT tipo_usuario FROM usuarios WHERE usu_id = ?",
      [usu_id]
    );

    if (checkUser.length === 0) {
      return res.status(404).json({ success: false, error: "Usuario no encontrado" });
    }

    if (checkUser[0].tipo_usuario === 'admin') {
      return res.status(403).json({ success: false, error: "No se puede modificar un administrador" });
    }

    // Construir query de actualización dinámicamente
    const updates = [];
    const values = [];

    if (nombres !== undefined) {
      updates.push("usu_nombres = ?");
      values.push(nombres);
    }
    if (apellidos !== undefined) {
      updates.push("usu_apellidos = ?");
      values.push(apellidos);
    }
    if (email !== undefined) {
      // Verificar que el email no esté en uso por otro usuario
      const [emailCheck] = await promisePool.query(
        "SELECT usu_id FROM usuarios WHERE usu_email = ? AND usu_id != ?",
        [email, usu_id]
      );
      if (emailCheck.length > 0) {
        return res.status(400).json({ success: false, error: "El correo electrónico ya está en uso" });
      }
      updates.push("usu_email = ?");
      values.push(email);
    }
    if (fechaNacimiento !== undefined) {
      updates.push("fecha_nacimiento = ?");
      values.push(fechaNacimiento);
    }
    if (activo !== undefined) {
      updates.push("activo = ?");
      values.push(activo ? 1 : 0);
    }

    if (updates.length === 0) {
      return res.status(400).json({ success: false, error: "No hay campos para actualizar" });
    }

    values.push(usu_id);

    const query = `UPDATE usuarios SET ${updates.join(", ")} WHERE usu_id = ?`;
    await promisePool.query(query, values);

    console.log("✅ Usuario actualizado:", usu_id);

    res.json({
      success: true,
      message: "Usuario actualizado correctamente"
    });
  } catch (error) {
    console.error("❌ Error en PUT /usuario/:usu_id:", error.message);
    res.status(500).json({ success: false, error: "Error al actualizar usuario: " + error.message });
  }
});

// DELETE /usuario/:usu_id - Eliminar usuario (soft delete, solo administradores)
app.delete("/usuario/:usu_id", async (req, res) => {
  console.log("🗑️ Eliminar usuario:", req.params.usu_id);

  try {
    const usu_id = req.params.usu_id;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ success: false, error: "ID de usuario inválido" });
    }

    // Verificar que el usuario existe y no es administrador
    const [checkUser] = await promisePool.query(
      "SELECT tipo_usuario FROM usuarios WHERE usu_id = ?",
      [usu_id]
    );

    if (checkUser.length === 0) {
      return res.status(404).json({ success: false, error: "Usuario no encontrado" });
    }

    if (checkUser[0].tipo_usuario === 'admin') {
      return res.status(403).json({ success: false, error: "No se puede eliminar un administrador" });
    }

    // Soft delete: marcar como inactivo
    await promisePool.query(
      "UPDATE usuarios SET activo = 0 WHERE usu_id = ?",
      [usu_id]
    );

    console.log("✅ Usuario eliminado (soft delete):", usu_id);

    res.json({
      success: true,
      message: "Usuario eliminado correctamente"
    });
  } catch (error) {
    console.error("❌ Error en DELETE /usuario/:usu_id:", error.message);
    res.status(500).json({ success: false, error: "Error al eliminar usuario: " + error.message });
  }
});

// =====================================================
// ELIMINAR CUENTA PROPIA
// =====================================================
// DELETE /cuenta/eliminar/:usu_id - Eliminar cuenta propia del usuario
app.delete("/cuenta/eliminar/:usu_id", async (req, res) => {
  console.log("🗑️ Eliminar cuenta propia:", req.params.usu_id);

  try {
    const usu_id = req.params.usu_id;

    if (!usu_id || isNaN(usu_id)) {
      return res.status(400).json({ success: false, error: "ID de usuario inválido" });
    }

    // Verificar que el usuario existe y está activo
    const [checkUser] = await promisePool.query(
      "SELECT tipo_usuario, activo FROM usuarios WHERE usu_id = ?",
      [usu_id]
    );

    if (checkUser.length === 0) {
      return res.status(404).json({ success: false, error: "Usuario no encontrado" });
    }

    if (checkUser[0].activo === 0) {
      return res.status(400).json({ success: false, error: "La cuenta ya está eliminada" });
    }

    // No permitir eliminar administradores
    if (checkUser[0].tipo_usuario === 'admin') {
      return res.status(403).json({ success: false, error: "No se puede eliminar una cuenta de administrador" });
    }

    // Soft delete: marcar como inactivo
    await promisePool.query(
      "UPDATE usuarios SET activo = 0 WHERE usu_id = ?",
      [usu_id]
    );

    console.log("✅ Cuenta eliminada (soft delete):", usu_id);

    res.json({
      success: true,
      message: "Cuenta eliminada correctamente"
    });
  } catch (error) {
    console.error("❌ Error en DELETE /cuenta/eliminar/:usu_id:", error.message);
    res.status(500).json({ success: false, error: "Error al eliminar cuenta: " + error.message });
  }
});

// =====================================================
// TABLA DE EVALUACIÓN COMPLETA PARA ADMINISTRADORES
// =====================================================
// GET /admin/evaluacion-completa - Tabla combinada con todos los datos y promedios
app.get("/admin/evaluacion-completa", async (req, res) => {
  console.log("📊 Solicitud de tabla de evaluación completa");

  try {
    const query = `
      SELECT 
        u.usu_id,
        u.usu_nombres,
        u.usu_apellidos,
        u.usu_email,
        u.fecha_nacimiento,
        TIMESTAMPDIFF(YEAR, u.fecha_nacimiento, CURDATE()) AS edad,
        u.fecha_registro,
        
        -- Estadísticas de actividad
        COUNT(DISTINCT c.cuestionario_id) AS total_cuestionarios,
        COUNT(DISTINCT t.test_id) AS total_tests,
        COUNT(DISTINCT e.encuesta_id) AS total_encuestas,
        COUNT(DISTINCT ja.juego_id) AS total_juegos_alimentos,
        COUNT(DISTINCT jc.juego_id) AS total_juegos_combinaciones,
        
        -- Promedios de scores
        COALESCE(AVG(t.score), 0) AS promedio_test_conocimiento,
        COALESCE(AVG(e.score), 0) AS promedio_encuesta_satisfaccion,
        COALESCE(AVG(ja.score), 0) AS promedio_juego_alimentos,
        COALESCE(AVG(jc.score), 0) AS promedio_juego_combinaciones,
        
        -- Última actividad
        GREATEST(
          COALESCE(MAX(c.fecha_creacion), '1970-01-01'),
          COALESCE(MAX(t.fecha_creacion), '1970-01-01'),
          COALESCE(MAX(e.fecha_creacion), '1970-01-01'),
          COALESCE(MAX(ja.fecha_creacion), '1970-01-01'),
          COALESCE(MAX(jc.fecha_creacion), '1970-01-01')
        ) AS ultima_actividad
        
      FROM usuarios u
      LEFT JOIN cuestionarios c ON u.usu_id = c.usu_id
      LEFT JOIN test_conocimiento t ON u.usu_id = t.usu_id
      LEFT JOIN encuesta_satisfaccion e ON u.usu_id = e.usu_id
      LEFT JOIN juego_alimentos ja ON u.usu_id = ja.usu_id
      LEFT JOIN juego_combinaciones jc ON u.usu_id = jc.usu_id
      WHERE u.tipo_usuario = 'usuario' AND u.activo = 1
      GROUP BY u.usu_id, u.usu_nombres, u.usu_apellidos, u.usu_email, u.fecha_nacimiento, u.fecha_registro
      ORDER BY u.usu_nombres, u.usu_apellidos
    `;

    const [results] = await promisePool.query(query);

    // Calcular promedios generales
    const totalUsuarios = results.length;
    const promediosGenerales = {
      promedio_test_conocimiento: 0,
      promedio_encuesta_satisfaccion: 0,
      promedio_juego_alimentos: 0,
      promedio_juego_combinaciones: 0
    };

    if (totalUsuarios > 0) {
      results.forEach(user => {
        promediosGenerales.promedio_test_conocimiento += parseFloat(user.promedio_test_conocimiento) || 0;
        promediosGenerales.promedio_encuesta_satisfaccion += parseFloat(user.promedio_encuesta_satisfaccion) || 0;
        promediosGenerales.promedio_juego_alimentos += parseFloat(user.promedio_juego_alimentos) || 0;
        promediosGenerales.promedio_juego_combinaciones += parseFloat(user.promedio_juego_combinaciones) || 0;
      });

      promediosGenerales.promedio_test_conocimiento = (promediosGenerales.promedio_test_conocimiento / totalUsuarios).toFixed(2);
      promediosGenerales.promedio_encuesta_satisfaccion = (promediosGenerales.promedio_encuesta_satisfaccion / totalUsuarios).toFixed(2);
      promediosGenerales.promedio_juego_alimentos = (promediosGenerales.promedio_juego_alimentos / totalUsuarios).toFixed(2);
      promediosGenerales.promedio_juego_combinaciones = (promediosGenerales.promedio_juego_combinaciones / totalUsuarios).toFixed(2);
    }

    // Formatear respuesta
    const usuarios = results.map(user => ({
      id: user.usu_id,
      nombres: user.usu_nombres,
      apellidos: user.usu_apellidos,
      email: user.usu_email,
      fechaNacimiento: user.fecha_nacimiento ? user.fecha_nacimiento.toISOString().split('T')[0] : null,
      edad: user.edad,
      fechaRegistro: user.fecha_registro,
      estadisticas: {
        totalCuestionarios: user.total_cuestionarios,
        totalTests: user.total_tests,
        totalEncuestas: user.total_encuestas,
        totalJuegosAlimentos: user.total_juegos_alimentos,
        totalJuegosCombinaciones: user.total_juegos_combinaciones
      },
      promedios: {
        testConocimiento: parseFloat(user.promedio_test_conocimiento).toFixed(2),
        encuestaSatisfaccion: parseFloat(user.promedio_encuesta_satisfaccion).toFixed(2),
        juegoAlimentos: parseFloat(user.promedio_juego_alimentos).toFixed(2),
        juegoCombinaciones: parseFloat(user.promedio_juego_combinaciones).toFixed(2)
      },
      ultimaActividad: user.ultima_actividad
    }));

    console.log(`✅ Tabla de evaluación obtenida: ${usuarios.length} usuarios`);

    res.json({
      success: true,
      total: usuarios.length,
      promediosGenerales: promediosGenerales,
      usuarios: usuarios
    });
  } catch (error) {
    console.error("❌ Error en GET /admin/evaluacion-completa:", error.message);
    console.error("Stack:", error.stack);
    res.status(500).json({ success: false, error: "Error al obtener tabla de evaluación: " + error.message });
  }
});

// Manejo de errores
app.use((err, req, res, next) => {
  console.error("Error no manejado:", err);
  res.status(500).json({ error: "Error interno del servidor" });
});
