// Script para verificar la configuración del correo
require('dotenv').config();
const emailService = require('./emailService');

async function testConfig() {
  console.log('\n🔍 Verificando configuración de correo...\n');
  
  // Verificar variables de entorno
  console.log('1. Variables de entorno:');
  const emailUser = process.env.EMAIL_USER || '';
  const emailPassword = process.env.EMAIL_PASSWORD || '';
  
  if (!emailUser || emailUser === 'tu_email@gmail.com') {
    console.log('   ❌ EMAIL_USER no configurado o tiene valor por defecto');
  } else {
    console.log(`   ✅ EMAIL_USER: ${emailUser}`);
  }
  
  if (!emailPassword || emailPassword === 'tu_contraseña_aplicacion' || emailPassword.includes('REEMPLAZA')) {
    console.log('   ❌ EMAIL_PASSWORD no configurado o tiene valor por defecto');
    console.log('   ⚠️  Debes reemplazar EMAIL_PASSWORD con tu contraseña de aplicación real');
  } else {
    const passwordLength = emailPassword.replace(/\s/g, '').length;
    console.log(`   ✅ EMAIL_PASSWORD configurado (${passwordLength} caracteres)`);
    if (passwordLength !== 16) {
      console.log('   ⚠️  La contraseña de aplicación debería tener 16 caracteres');
    }
  }
  
  console.log('\n2. Verificando conexión con Gmail...');
  const isConfigured = await emailService.verificarConfiguracion();
  
  if (isConfigured) {
    console.log('   ✅ Conexión exitosa con Gmail');
    console.log('   ✅ El servicio de correo está listo para enviar mensajes\n');
  } else {
    console.log('   ❌ Error al conectar con Gmail');
    console.log('\n   Posibles causas:');
    console.log('   - Contraseña incorrecta');
    console.log('   - Usando contraseña normal en lugar de contraseña de aplicación');
    console.log('   - Verificación en 2 pasos no activada');
    console.log('   - Formato incorrecto del archivo .env\n');
  }
  
  console.log('📝 Revisa SOLUCION_ERROR_535.md para más ayuda\n');
}

testConfig().catch(console.error);

