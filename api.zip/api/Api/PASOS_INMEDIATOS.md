# 🚨 ACCIÓN INMEDIATA REQUERIDA

## ❌ Problema Detectado

El diagnóstico muestra:
```
❌ EMAIL_PASSWORD no configurado o tiene valor por defecto
```

Esto significa que **aún tienes el valor de ejemplo** en el archivo `.env` y necesitas reemplazarlo con tu contraseña real de Gmail.

## ✅ Solución Rápida (5 minutos)

### Paso 1: Obtener Contraseña de Aplicación de Gmail

1. **Abre tu navegador** y ve a:
   ```
   https://myaccount.google.com/apppasswords
   ```

2. Si no ves la opción "Contraseñas de aplicaciones":
   - Primero activa "Verificación en 2 pasos" en: https://myaccount.google.com/security
   - Luego vuelve a apppasswords

3. **Selecciona:**
   - **Aplicación:** Correo
   - **Dispositivo:** Otro (nombre personalizado)
   - **Nombre:** `Inspira Salud API`
   - Haz clic en **"Generar"**

4. **Copia la contraseña de 16 caracteres** que aparece
   - Ejemplo: `abcd efgh ijkl mnop`
   - O sin espacios: `abcdefghijklmnop`

### Paso 2: Editar el Archivo .env

1. **Abre el Explorador de Archivos de Windows**

2. **Navega a:**
   ```
   D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api
   ```

3. **Busca el archivo `.env`** (puede estar oculto, activa "Mostrar archivos ocultos")

4. **Haz clic derecho** → **Abrir con** → **Bloc de notas**

5. **Deberías ver algo como:**
   ```env
   EMAIL_USER=kenisstore18@gmail.com
   EMAIL_PASSWORD=REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION
   ```

6. **Borra** `REEMPLAZA_CON_TU_CONTRASEÑA_DE_APLICACION`

7. **Pega** tu contraseña de aplicación (la de 16 caracteres que copiaste)

8. **Debería quedar así** (ejemplo):
   ```env
   EMAIL_USER=kenisstore18@gmail.com
   EMAIL_PASSWORD=abcd efgh ijkl mnop
   ```

9. **Guarda el archivo** (Ctrl+S)

10. **Cierra el Bloc de notas**

### Paso 3: Verificar

El servidor debería reiniciarse automáticamente. Deberías ver:

```
✅ Servidor de correo listo para enviar mensajes
✅ Servicio de correo configurado correctamente.
```

### Paso 4: Probar

1. Desde la app Android, ve a "Recuperar Contraseña"
2. Ingresa: `kenisstore18@gmail.com`
3. Revisa los logs, deberías ver:
   ```
   ✅ Código enviado por correo a: kenisstore18@gmail.com
   ```
4. Revisa tu correo, deberías recibir el código ✨

## 🔍 Verificar que Funcionó

Ejecuta este comando para verificar:
```bash
cd "D:\Prototipos\prueba1\Prueba nueva noviembre\api\Api"
node test-config.js
```

Deberías ver:
```
✅ EMAIL_PASSWORD configurado (16 caracteres)
✅ Conexión exitosa con Gmail
```

## ⚠️ Errores Comunes

### Error: "Invalid login"
- **Causa:** Estás usando tu contraseña normal de Gmail
- **Solución:** Debes usar una **contraseña de aplicación** (16 caracteres)

### Error: "No se encuentra el archivo .env"
- **Causa:** El archivo puede estar oculto
- **Solución:** En el Explorador de Archivos, activa "Mostrar archivos ocultos"

### El servidor no se reinicia
- **Solución:** Reinicia manualmente con `npm run dev`

## 📝 Formato Correcto del Archivo .env

**✅ CORRECTO:**
```env
EMAIL_USER=kenisstore18@gmail.com
EMAIL_PASSWORD=abcd efgh ijkl mnop
```

**❌ INCORRECTO (con comillas):**
```env
EMAIL_USER="kenisstore18@gmail.com"
EMAIL_PASSWORD="abcd efgh ijkl mnop"
```

**❌ INCORRECTO (con espacios alrededor del =):**
```env
EMAIL_USER = kenisstore18@gmail.com
EMAIL_PASSWORD = abcd efgh ijkl mnop
```

---

**Una vez que completes estos pasos, los correos se enviarán automáticamente** 🎉

