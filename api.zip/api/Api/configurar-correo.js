#!/usr/bin/env node

/**
 * Script interactivo para configurar el servicio de correo
 * Ejecuta: node configurar-correo.js
 */

const readline = require('readline');
const fs = require('fs');
const path = require('path');

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function pregunta(pregunta) {
  return new Promise((resolve) => {
    rl.question(pregunta, (respuesta) => {
      resolve(respuesta);
    });
  });
}

async function main() {
  console.log('\n' + '═'.repeat(70));
  console.log('  CONFIGURACIÓN DEL SERVICIO DE CORREO ELECTRÓNICO');
  console.log('═'.repeat(70) + '\n');

  const envPath = path.join(__dirname, '.env');
  let envContent = '';

  // Leer archivo .env si existe
  if (fs.existsSync(envPath)) {
    envContent = fs.readFileSync(envPath, 'utf8');
    console.log('✅ Archivo .env encontrado\n');
  } else {
    console.log('📝 Creando nuevo archivo .env\n');
  }

  // Obtener EMAIL_USER
  let emailUser = '';
  const userMatch = envContent.match(/EMAIL_USER=(.+)/);
  if (userMatch && userMatch[1] && !userMatch[1].includes('tu_email')) {
    emailUser = userMatch[1].trim();
    console.log(`📧 Correo actual: ${emailUser}`);
    const usarActual = await pregunta('¿Usar este correo? (S/n): ');
    if (usarActual.toLowerCase() !== 'n') {
      console.log(`✅ Usando: ${emailUser}\n`);
    } else {
      emailUser = '';
    }
  }

  if (!emailUser) {
    emailUser = await pregunta('📧 Ingresa tu correo de Gmail: ');
    if (!emailUser.includes('@gmail.com')) {
      console.log('⚠️  Advertencia: Se recomienda usar una cuenta de Gmail\n');
    }
  }

  // Obtener contraseña de aplicación
  console.log('\n' + '─'.repeat(70));
  console.log('🔑 CONTRASEÑA DE APLICACIÓN DE GMAIL');
  console.log('─'.repeat(70));
  console.log('\nPara obtener tu contraseña de aplicación:');
  console.log('1. Ve a: https://myaccount.google.com/apppasswords');
  console.log('2. Si no ves la opción, activa "Verificación en 2 pasos" primero');
  console.log('3. Selecciona: Correo → Otro → "Inspira Salud API"');
  console.log('4. Copia la contraseña de 16 caracteres\n');

  const passwordMatch = envContent.match(/EMAIL_PASSWORD=(.+)/);
  const tienePasswordDefault = passwordMatch && (
    passwordMatch[1].includes('REEMPLAZA') || 
    passwordMatch[1].includes('tu_contraseña')
  );

  if (tienePasswordDefault) {
    console.log('⚠️  La contraseña actual tiene un valor por defecto\n');
  }

  const emailPassword = await pregunta('🔑 Pega tu contraseña de aplicación (16 caracteres): ');

  if (!emailPassword || emailPassword.length < 10) {
    console.log('\n❌ Error: La contraseña parece ser muy corta');
    console.log('   Debe tener 16 caracteres (puede incluir espacios)\n');
    rl.close();
    return;
  }

  // Crear contenido del archivo .env
  const nuevoContenido = `EMAIL_USER=${emailUser}
EMAIL_PASSWORD=${emailPassword}
`;

  // Guardar archivo
  try {
    fs.writeFileSync(envPath, nuevoContenido, 'utf8');
    console.log('\n✅ Archivo .env actualizado exitosamente\n');
  } catch (error) {
    console.error('\n❌ Error al guardar el archivo:', error.message);
    rl.close();
    return;
  }

  // Verificar configuración
  console.log('🧪 Verificando configuración...\n');
  
  // Cargar variables de entorno
  require('dotenv').config();
  const emailService = require('./emailService');

  emailService.verificarConfiguracion().then(isReady => {
    if (isReady) {
      console.log('✅ ¡Configuración exitosa!');
      console.log('✅ El servicio de correo está listo para enviar mensajes\n');
      console.log('🎉 Puedes probar ahora desde la app:\n');
      console.log('   1. Ve a "Recuperar Contraseña"');
      console.log(`   2. Ingresa: ${emailUser}`);
      console.log('   3. Revisa tu correo para recibir el código\n');
    } else {
      console.log('❌ Error en la configuración');
      console.log('\nPosibles causas:');
      console.log('  - Contraseña incorrecta');
      console.log('  - Usando contraseña normal en lugar de contraseña de aplicación');
      console.log('  - Verificación en 2 pasos no activada');
      console.log('\n💡 Revisa SOLUCION_ERROR_535.md para más ayuda\n');
    }
    rl.close();
  }).catch(error => {
    console.error('❌ Error:', error.message);
    rl.close();
  });
}

main();

